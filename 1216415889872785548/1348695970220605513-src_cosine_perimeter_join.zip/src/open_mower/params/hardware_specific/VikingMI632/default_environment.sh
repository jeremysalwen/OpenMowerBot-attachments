# Set default GPS antenna offset
export OM_ANTENNA_OFFSET_X=${OM_ANTENNA_OFFSET_X:--0.075}
export OM_ANTENNA_OFFSET_Y=${OM_ANTENNA_OFFSET_Y:-0.0}

# Set distance between wheels in m
export OM_WHEEL_DISTANCE_M=${OM_WHEEL_DISTANCE_M:-0.465}

# Set default ticks/m
export OM_WHEEL_TICKS_PER_M=${OM_WHEEL_TICKS_PER_M:-2864.0}

# Set mow motor speed in erpm
export OM_MOW_SPEED_ERPM=${OM_MOW_SPEED_ERPM:-6000.0}

# Set your mow motor speed control method
export OM_MOWER_MOW_ERPM=${OM_MOWER_MOW_ERPM:-True}

# Enable cutter height control
export OM_MOWER_MOW_HEIGHT_EN=${OM_MOWER_MOW_HEIGHT_EN:-True}

# Set min cutter height
export OM_MIN_MOW_HEIGHT=${OM_MIN_MOW_HEIGHT:-20}

# Set max cutter height
export OM_MAX_MOW_HEIGHT=${OM_MAX_MOW_HEIGHT:-60}
