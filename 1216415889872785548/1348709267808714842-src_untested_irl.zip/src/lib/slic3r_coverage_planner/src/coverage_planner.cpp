//
// Created by Clemens Elflein on 27.08.21.
//

#include "ros/ros.h"

#include <boost/range/adaptor/reversed.hpp>

#include "ExPolygon.hpp"
#include "Polyline.hpp"
#include "Fill/FillRectilinear.hpp"
#include "Fill/FillConcentric.hpp"


#include "slic3r_coverage_planner/PlanPath.h"
#include "visualization_msgs/MarkerArray.h"
#include "Surface.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <Fill/FillPlanePath.hpp>
#include <PerimeterGenerator.hpp>

#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "ClipperUtils.hpp"
#include "ExtrusionEntityCollection.hpp"

#include <map>

#define DEF_POINT_SPACING 0.1
#define MAX_POINT_SPACING 0.3
#define MIN_POINT_SPACING 0.08


bool visualize_plan;
ros::Publisher marker_array_publisher;

double transition_distance_m = 0.0;
bool use_linear_transition = false;

void
createMarkers(const slic3r_coverage_planner::PlanPathRequest &planning_request,
              const slic3r_coverage_planner::PlanPathResponse &planning_result,
              visualization_msgs::MarkerArray &markerArray) {

    std::vector<std_msgs::ColorRGBA> colors;

    {
        std_msgs::ColorRGBA color;
        color.r = 1.0;
        color.g = 0.0;
        color.b = 0.0;
        color.a = 1.0;
        colors.push_back(color);
    }
    {
        std_msgs::ColorRGBA color;
        color.r = 0.0;
        color.g = 1.0;
        color.b = 0.0;
        color.a = 1.0;
        colors.push_back(color);
    }
    {
        std_msgs::ColorRGBA color;
        color.r = 0.0;
        color.g = 0.0;
        color.b = 1.0;
        color.a = 1.0;
        colors.push_back(color);
    }
    {
        std_msgs::ColorRGBA color;
        color.r = 1.0;
        color.g = 1.0;
        color.b = 0.0;
        color.a = 1.0;
        colors.push_back(color);
    }
    {
        std_msgs::ColorRGBA color;
        color.r = 1.0;
        color.g = 0.0;
        color.b = 1.0;
        color.a = 1.0;
        colors.push_back(color);
    }
    {
        std_msgs::ColorRGBA color;
        color.r = 0.0;
        color.g = 1.0;
        color.b = 1.0;
        color.a = 1.0;
        colors.push_back(color);
    }
    {
        std_msgs::ColorRGBA color;
        color.r = 1.0;
        color.g = 1.0;
        color.b = 1.0;
        color.a = 1.0;
        colors.push_back(color);
    }

    // Create markers for the input polygon
    {
        // Walk through the paths we send to the navigation stack
        auto &path = planning_request.outline.points;
        // Each group gets a single line strip as marker
        visualization_msgs::Marker marker;

        marker.header.frame_id = "map";
        marker.ns = "mower_map_service_lines";
        marker.id = static_cast<int>(markerArray.markers.size());
        marker.frame_locked = true;
        marker.action = visualization_msgs::Marker::ADD;
        marker.type = visualization_msgs::Marker::SPHERE_LIST;
        marker.color = colors[0];
        marker.pose.orientation.w = 1;
        marker.scale.x = marker.scale.y = marker.scale.z = 0.02;

        // Add the points to the line strip
        for (auto &point: path) {

            geometry_msgs::Point vpt;
            vpt.x = point.x;
            vpt.y = point.y;
            marker.points.push_back(vpt);
        }
        markerArray.markers.push_back(marker);

        // Create markers for start and end
        if (!path.empty()) {
            visualization_msgs::Marker marker{};

            marker.header.frame_id = "map";
            marker.ns = "mower_map_service_lines";
            marker.id = static_cast<int>(markerArray.markers.size());
            marker.frame_locked = true;
            marker.action = visualization_msgs::Marker::ADD;
            marker.type = visualization_msgs::Marker::SPHERE;
            marker.color = colors[0];
            marker.pose.position.x = path.front().x;
            marker.pose.position.y = path.front().y;
            marker.scale.x = 0.1;
            marker.scale.y = marker.scale.z = 0.1;
            markerArray.markers.push_back(marker);
        }
    }


    // keep track of the color used last, so that we can use a new one for each path
    uint32_t cidx = 0;

    uint32_t path_index = 0;

    // Walk through the paths we send to the navigation stack
    for (auto &path: planning_result.paths) {
        // Each group gets a single line strip as marker
        visualization_msgs::Marker marker;

        marker.header.frame_id = "map";
        marker.ns = "mower_map_service_lines";
        marker.id = static_cast<int>(markerArray.markers.size());
        marker.frame_locked = true;
        marker.action = visualization_msgs::Marker::ADD;
        marker.type = visualization_msgs::Marker::LINE_STRIP;
        marker.color = colors[cidx];
        marker.pose.orientation.w = 1;
        marker.scale.x = marker.scale.y = marker.scale.z = 0.02;

        // Add the points to the line strip
        for (auto &point: path.path.poses) {

            geometry_msgs::Point vpt;
            vpt.x = point.pose.position.x;
            vpt.y = point.pose.position.y;
            marker.points.push_back(vpt);
        }
        markerArray.markers.push_back(marker);

        // Create markers for start
        if (!path.path.poses.empty()) {
            visualization_msgs::Marker marker;

            marker.header.frame_id = "map";
            marker.ns = "mower_map_service_lines";
            marker.id = static_cast<int>(markerArray.markers.size());
            marker.frame_locked = true;
            marker.action = visualization_msgs::Marker::ADD;
            marker.type = visualization_msgs::Marker::ARROW;
            marker.color = colors[cidx];
            marker.pose = path.path.poses.front().pose;
            marker.scale.x = 0.2;
            marker.scale.y = marker.scale.z = 0.05;
            markerArray.markers.push_back(marker);
        }

        // Add text to show order of mowing
        if (!path.path.poses.empty() && !path.is_outline) {
            visualization_msgs::Marker marker;

            marker.header.frame_id = "map";
            marker.ns = "mower_map_service_lines";
            marker.id = static_cast<int>(markerArray.markers.size());
            marker.frame_locked = true;
            marker.action = visualization_msgs::Marker::ADD;
            marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
            marker.color = colors[cidx];
            marker.pose = path.path.poses.front().pose;
            marker.scale.x = marker.scale.y = marker.scale.z = 0.5;
            marker.text = std::to_string(path_index); 
            markerArray.markers.push_back(marker);
            path_index++;
        }

        // New color for a new path
        cidx = (cidx + 1) % colors.size();
    }
}

void traverse_from_left(std::vector<PerimeterGeneratorLoop> &contours, std::vector<Polygons> &line_groups) {
    for (auto &contour: contours) {
        if (contour.children.empty()) {
            line_groups.push_back(Polygons());
        } else {
            traverse_from_left(contour.children, line_groups);
        }
        line_groups.back().push_back(contour.polygon);
    }
}

void traverse_from_right(std::vector<PerimeterGeneratorLoop> &contours, std::vector<Polygons> &line_groups) {
    for (auto &contour: boost::adaptors::reverse(contours)) {
        if (contour.children.empty()) {
            line_groups.push_back(Polygons());
        } else {
            traverse_from_right(contour.children, line_groups);
        }
        line_groups.back().push_back(contour.polygon);
    }
}

slic3r_coverage_planner::Path determinePathForOutline(std_msgs::Header &header, Slic3r::Polygon &outline_poly, Slic3r::Polygons &group, bool isObstacle, Point start_point, Point *areaLastPoint, bool *areaLastPointValid) {
    slic3r_coverage_planner::Path path;

    /**
     * Some postprocessing is done here. Until now we just have polygons (just points).
     * First we convert from the polygon to a set of equally spaced points
     * Then we search for a suitable start point on the ploygon (first loop near the recording start point and
     *      subsequent loops near the last split point)
     * Then we add a transition path to go from of the last polygon and the start of the next.
     * Finally we can calculate the orientation at each point by looking at the connection line between two points.
     */

    path.is_outline = true;
    path.path.header = header;
    path.outline_start_index = 0;
    path.outline_end_index = 0;

    Points transition_points;
    double firstLoopLength = 0.0;

    int obstacle_loop_count = 0; //used to detect first valid loop, can't use i== as might skip point ("Skipping single dot")
    
    double transition_length = transition_distance_m; //in m
    unsigned int num_trans_points = (unsigned int)((transition_length + (DEF_POINT_SPACING/2.0))/DEF_POINT_SPACING);
    ROS_INFO_STREAM("Interpolated transition, target transition length:"  << transition_length << "m, " << num_trans_points << " points");

    for (int i = 0; i < group.size(); i++) {
        int used_trans_points = num_trans_points;
        // The transition path uses the first part of two oconsecutive loops, for best results these should be radially
        // aligned so adjust the point spacing on subsequent loops, relative to the first one, to ensure this
        double pointSpacing = DEF_POINT_SPACING;
        double pathLength = unscale(group[i].length());
        if(i==0)
            firstLoopLength = pathLength;            
        else
            pointSpacing = pointSpacing * (pathLength/firstLoopLength);

        if(pointSpacing > MAX_POINT_SPACING) {
            ROS_INFO_STREAM("Interpolated transition, point spacing too high:" << pathLength << "m, set to: " << MAX_POINT_SPACING << "m");
            pointSpacing = MAX_POINT_SPACING;
        }
        else if(pointSpacing < MIN_POINT_SPACING) {
            ROS_INFO_STREAM("Interpolated transition, point spacing too low:" << pathLength << "m, set to: " << MIN_POINT_SPACING << "m");
            pointSpacing = MIN_POINT_SPACING;
        }

        auto points = group[i].equally_spaced_points(scale_(pointSpacing));
        
        if (points.size() < 2) {
            ROS_INFO("Skipping single dot");
            continue;
        }
        ROS_INFO_STREAM("Got " << points.size() << " points");
        ROS_INFO_STREAM("Interpolated transition, path length:" << pathLength << "m ,point spacing:" << pointSpacing);

        // Cannot use i==0 here, because we might skip/have skipped a path ("Skipping single dot")
        if (path.path.poses.empty()) {
            // innermost group, split at point nearest to recording start/polygon start point
            double min_start_distance = INFINITY;
                int min_start_index = 0;
                for (int start_search = 0; start_search < points.size(); ++start_search) {
                    const auto &pt = points[start_search];
                    const auto pt_x = unscale(pt.x);
                    const auto pt_y = unscale(pt.y);
                    double distance = sqrt((pt_x - start_point.x) * (pt_x - start_point.x) +
                                           (pt_y - start_point.y) * (pt_y - start_point.y));

                    if (distance < min_start_distance) {
                        min_start_distance = distance;
                        min_start_index = start_search;
                    }
                }
                std::rotate(points.begin(), points.begin() + min_start_index, points.end());
                used_trans_points = num_trans_points;
                if(points.size() < used_trans_points) used_trans_points = points.size();
                transition_points = {points.begin(), points.begin() + used_trans_points};
                ROS_INFO_STREAM("Interpolated transition, loop: " << i << " ,poly size:" << points.size() << " ,split point:" << min_start_index);
                ROS_INFO_STREAM("Interpolated transition, used_trans_points:" << used_trans_points);

        } else {
            // Subsequent loop, find the split point so as to be closest to last split
            //Note - this isn't ideal on small obstacles, the small raduis means that the points on the 
            //two loops will diverge, it would be better to align on the center of the transtion to minimise this 
            //but not worth the bother as long as the transition length is kept reasonable
            auto lastPoint = transition_points.front();
            const auto last_x = unscale(lastPoint.x);
            const auto last_y = unscale(lastPoint.y);
            double min_distance = INFINITY;
            int min_split_index = 0;
            for (int split_index = 0; split_index < points.size(); ++split_index) {
                const auto &pt = points[split_index];
                const auto pt_x = unscale(pt.x);
                const auto pt_y = unscale(pt.y);
                double distance = sqrt((pt_x - last_x) * (pt_x - last_x) +
                                        (pt_y - last_y) * (pt_y - last_y));

                if (distance < min_distance) {
                    min_distance = distance;
                    min_split_index = split_index;
                }
            }
            
            // In order to smooth the transition we create a transition path based on the start of the last one and the start of the new one.
            ROS_INFO_STREAM("Interpolated transition, loop: " << i << " ,poly size:" << points.size() << " ,split point:" << min_split_index);
            std::rotate(points.begin(), points.begin() + min_split_index, points.end());
            auto old_transition_points = transition_points;

            used_trans_points = num_trans_points;
            if((points.size()<used_trans_points) || (old_transition_points.size()<used_trans_points)) {
                if(points.size() < old_transition_points.size())
                    used_trans_points = points.size();
                else
                    used_trans_points = old_transition_points.size();
            }
            transition_points = {points.begin(), points.begin() + used_trans_points};
            ROS_INFO_STREAM("Interpolated transition, used_trans_points:" << used_trans_points);
            //calculate transition move and modify start of loop
            for(int offset=0;offset<used_trans_points;offset++) {
                double path_pt_x = old_transition_points[offset].x;
                double path_pt_y = old_transition_points[offset].y;
                double poly_pt_x = points[offset].x;
                double poly_pt_y = points[offset].y;
                Point interpolated_pt{};
                double factor = 0.0;
                if(use_linear_transition)
                    factor = (double)offset/(double)(used_trans_points-1); //linear interpolation, best for long transition lengths
                else
                    factor = 1.0 - ((cos(M_PI*((double)offset/(used_trans_points-1))) + 1.0) /2.0); //cosine interpolation, best for short lengths
                interpolated_pt.x = (factor * (poly_pt_x - path_pt_x)) + path_pt_x;
                interpolated_pt.y = (factor * (poly_pt_y - path_pt_y)) + path_pt_y;
                //ROS_INFO_STREAM("X path:" << unscale(path_pt_x) << " ,poly:" << unscale(poly_pt_x) << " ,Interp:" << unscale(interpolated_pt.x));
                //ROS_INFO_STREAM("Y path:" << unscale(path_pt_y) << " ,poly:" << unscale(poly_pt_y) << " ,Interp:" << unscale(interpolated_pt.y));
                points[offset] = interpolated_pt;
            }
            ROS_INFO_STREAM("Interpolated transition, transition path added");
        }
        
        if(isObstacle) {
            if(obstacle_loop_count==0) { //if at end of inner loop (start of loop here but reversed later)
                path.outline_end_index = path.path.poses.size();
                ROS_INFO_STREAM("Obstruction outline ends at point " << path.outline_end_index);
            }
        }
        else {
            if(i==(group.size()-1)) { //if at start of outer loop
                path.outline_start_index = path.path.poses.size();
                ROS_INFO_STREAM("Area outline starts at point " << path.outline_start_index);
            }
        }

        if((i == group.size()-1) && !path.path.poses.empty()) //add transition on last loop but not if only have 1 loop
            points += transition_points;

        for (auto &pt: points) {
            if (!*areaLastPointValid) {
                *areaLastPoint = pt;
                *areaLastPointValid = true;
                continue;
            }

            // Direction for obstacle needs to be inversed compared to area outline, because we will reverse the point order later.
            auto dir = isObstacle ? *areaLastPoint - pt : pt - *areaLastPoint;

            double orientation = atan2(dir.y, dir.x);
            tf2::Quaternion q(0.0, 0.0, orientation);

            geometry_msgs::PoseStamped pose;
            pose.header = header;
            pose.pose.orientation = tf2::toMsg(q);
            pose.pose.position.x = unscale(areaLastPoint->x);
            pose.pose.position.y = unscale(areaLastPoint->y);
            pose.pose.position.z = 0;
            path.path.poses.push_back(pose);
            *areaLastPoint = pt;
        }

        if(isObstacle) {
            if(obstacle_loop_count==0) { //if at start of inner loop (end but reversed later)
                path.outline_start_index = path.path.poses.size();
                ROS_INFO_STREAM("Obstruction outline starts at point " << path.outline_start_index);
            }
            else if(obstacle_loop_count==1) { //if multiple loops include transition path
                path.outline_start_index += used_trans_points;
                ROS_INFO_STREAM("Obstruction outline (including transition) starts at point " << path.outline_start_index);
            }
            obstacle_loop_count++;
        }
        else {
            if(i==(group.size()-1)) { //if at end of outer loop
                path.outline_end_index = path.path.poses.size();
                ROS_INFO_STREAM("Area outline ends at point " << path.outline_end_index);
            }
        }
    }
    // finally, we add the final pose for "lastPoint" with the same orientation as the last poe
    geometry_msgs::PoseStamped pose;
    pose.header = header;
    pose.pose.orientation = path.path.poses.back().pose.orientation;
    pose.pose.position.x = unscale(areaLastPoint->x);
    pose.pose.position.y = unscale(areaLastPoint->y);
    pose.pose.position.z = 0;
    path.path.poses.push_back(pose);

    if(isObstacle) {
        // Reverse here to make the mower approach the obstacle instead of starting close to the obstacle
        std::reverse(path.path.poses.begin(), path.path.poses.end());
        // and update the markers
        path.outline_start_index = path.path.poses.size() - path.outline_start_index;
        path.outline_end_index = path.path.poses.size() - path.outline_end_index;
        
        ROS_INFO_STREAM("Reversed obstruction outline starts at point " << path.outline_start_index);
        ROS_INFO_STREAM("Reversed obstruction outline ends at point " << path.outline_end_index);
    }
    return path;
}

Polyline smooth_polyline(const Polyline &p, double clip_distance){
    if (p.points.size() < 3) return p;
    Polyline poly;
    poly.append(p.first_point());
    for (Points::const_iterator it = p.points.begin() + 1; it != p.points.end(); ++it) {
        Line segment(*(it-1), *it);
        if (segment.length() >= clip_distance * 3) {
            poly.append(segment.point_at(clip_distance));
            poly.append(segment.point_at(segment.length() - clip_distance));
        } else {
            poly.append(segment.point_at(segment.length()/2.0));
        }
    }
    poly.append(p.last_point());
    return poly;
}

Points sparse_spaced_points(const Polyline &p, double distance)
{
    Points points;
    
    for (Points::const_iterator it = p.points.begin() + 1; it != p.points.end(); ++it) {
        Points right_points;
        Line segment(*(it-1), *it);
        int i = 1;
        double used = 0.0;
        points.push_back(*(it-1));
        while( (distance * i + used) < segment.length()/2 )
        {
            points.push_back(segment.point_at(distance * i + used));
            right_points.push_back(segment.point_at(segment.length() - distance * i - used));
            used += distance * i;
            i *= 2;
        }
        points.insert(points.end(), right_points.rbegin(), right_points.rend());
    }
    points.push_back(p.last_point());
    return points;
}

struct fill_data_struct{
    double length;
    Slic3r::coord_t minX;
    Slic3r::coord_t maxX;
    Slic3r::coord_t minY;
    Slic3r::coord_t maxY;
    bool needs_processing;
};


Slic3r::Polylines extract_single_area_lines(Slic3r::Polygon pa, Slic3r::Polylines *fill_lines)
{
    //ROS_INFO_STREAM("Splitting lines on priority boundary intersection");
    Slic3r::Polylines output_lines, priority_output_lines;
    for (Slic3r::Polylines::iterator fl = fill_lines->begin(); fl != fill_lines->end(); fl++) {
        Slic3r::Polyline l;
        if(pa.contains(fl->first_point()) && pa.contains(fl->last_point())) {
            //ROS_INFO_STREAM("Priority fill line added");
            priority_output_lines.push_back(*fl);
        } else { //not contained
            Slic3r::Point intersect_pt;
            if(pa.intersection(*fl, &intersect_pt)) //at least 1 intersection
            {
                if(pa.contains(fl->first_point()))
                {
                    l.points.clear();
                    l.points.push_back(fl->first_point());
                    l.points.push_back(intersect_pt);
                    priority_output_lines.push_back(l);
                    l.points.clear();
                    l.points.push_back(intersect_pt);
                    l.points.push_back(fl->last_point());
                    output_lines.push_back(l);
                    //ROS_INFO_STREAM("Modifying line first point");
                } 
                else 
                {
                    if(pa.contains(fl->last_point())) 
                    {
                        l.points.clear();
                        l.points.push_back(intersect_pt); 
                        l.points.push_back(fl->last_point());
                        priority_output_lines.push_back(l);
                        l.points.clear();
                        l.points.push_back(fl->first_point()); 
                        l.points.push_back(intersect_pt);
                        output_lines.push_back(l);
                        //ROS_INFO_STREAM("Modifying line last point");
                    } 
                    else //must be multiple intersections
                    {
                        //ROS_INFO_STREAM("Adding line");
                        std::vector<Slic3r::Point> pts;
                        for(auto &pl: pa.lines())
                            if(pl.intersection(*fl, &intersect_pt))
                                pts.push_back(intersect_pt);
                        
                        if(pts.size() == 2) {//two points is pass through so process, one point is tangent so leave
                            int index_first = 1, index_last = 0;
                            if(fl->first_point().distance_to(pts[index_first]) > fl->first_point().distance_to(pts[index_last])) {
                                index_first = 0;
                                index_last = 1;
                            }
                            l.points.clear();
                            l.points.push_back(pts[index_first]);
                            l.points.push_back(pts[index_last]);
                            priority_output_lines.push_back(l);
                            l.points.clear();
                            l.points.push_back(fl->first_point()); 
                            l.points.push_back(pts[index_first]);
                            output_lines.push_back(l);
                            l.points.clear();
                            l.points.push_back(pts[index_last]); 
                            l.points.push_back(fl->last_point());
                            output_lines.push_back(l);
                        }
                    }
                }
            } 
            else { //not fully contained no intersection and so low priority line
                output_lines.push_back(*fl);
            }
        }
    }

    *fill_lines = output_lines;
    //ROS_INFO_STREAM("Finished processong priority areas, lines:" << output_lines.size() << ", priority_lines:" << priority_output_lines.size());
    return priority_output_lines;
}

Slic3r::Polylines extract_lines(slic3r_coverage_planner::PlanPathRequest req, Slic3r::Polylines *fill_lines)
{
    Slic3r::Polylines output_lines;
    //split any lines that are partially inside priority zones
    Slic3r::Polygons priorities;
    for (auto &priority: req.priority) {
        //convert each priority area message to polygon
        Slic3r::Polygon priority_poly;
        for (auto &pt: priority.points) {
            priority_poly.points.push_back(Point(scale_(pt.x), scale_(pt.y)));
        }
        priorities.push_back(priority_poly);
    }

    Slic3r::Polylines priority_lines;
    //ROS_INFO_STREAM("Processong priority areas, lines:" << fill_lines->size() << ", priority_lines:" << priority_lines.size());
    int num = 0;
    for(auto &pa: priorities) {
        append_to(priority_lines, extract_single_area_lines(pa, fill_lines));
        //ROS_INFO_STREAM("Finished processing priority areas:" << num++ << ", lines:" << fill_lines->size() << ", priority_lines:" << priority_lines.size());
    }

    return priority_lines;
}

struct fill_line_struct{
    Slic3r::Polyline line;
    bool available;
};

struct perim_points_struct{
    int line_index;
    bool first_match;
    Slic3r::Point match_point;
};

#define SEARCH_TOLERANCE (scale_(0.001)) //quantisation on rotations can cause errors to creep in so use higher value than standard (=10x SCALED_EPSILON)
//should really create lines in the same rotated frame to avoid this problem but not worth the effort at this point int time.

Slic3r::Polylines join_fill_lines(slic3r_coverage_planner::PlanPathRequest req, Slic3r::Polygons inner, Slic3r::Polylines fill_lines, bool priority_area)
{
    Slic3r::Polylines reordered_lines;
    Slic3r::Point origin(scale_(0.0),scale_(0.0));
    double rot_angle = -req.angle;

    if(fill_lines.empty()) {
        ROS_INFO_STREAM("No lines to process");
        return reordered_lines;
    }

    // create perimeter to use for line joining
    Polygons perimeters;
    perimeters = offset(inner, -scale_(req.distance)/2.0);
    int path_num = 0;

    Slic3r::Polygons priorities;
    for (auto &priority: req.priority) {
        //convert each priority area message to polygon
        Slic3r::Polygon priority_poly;
        for (auto &pt: priority.points) {
            priority_poly.points.push_back(Point(scale_(pt.x), scale_(pt.y)));
        }
        if(priority_area)
            priority_poly.make_counter_clockwise();
        else
            priority_poly.make_clockwise();
        perimeters.push_back(priority_poly);
    }

    //rotate back to 0deg so that lines traverse in constant Y
    for (auto &perimeter: perimeters) {
        perimeter.rotate(rot_angle, origin);
    }

    //generate vector of lines
    std::vector<fill_line_struct> lines;
    for(auto &ln: fill_lines) {
        ln.rotate(rot_angle, origin);
        fill_line_struct line = {ln, true};
        lines.push_back(line);
    }
        
    //generate vector of multimap of lines for each perimeter
    std::vector<std::multimap<int, perim_points_struct>> perimeters_lines;
    int perim_num = 0;
    for(auto &perim: perimeters) {
        std::multimap<int, perim_points_struct> perimeter_lines;
        //ROS_INFO_STREAM("Processing perimeter:" << perim_num++);
        int perim_line_num = 0; //slightly messy way to keep track of index but allows MUCH faster loops!
        for(auto &perim_line: perim.lines()) {
            int line_num = 0;  
            for(auto &l: lines) {
                    bool first_match = (l.line.first_point().distance_to(l.line.first_point().projection_onto(perim_line))<SEARCH_TOLERANCE);
                    bool last_match = (l.line.last_point().distance_to(l.line.last_point().projection_onto(perim_line))<SEARCH_TOLERANCE);
                    if(first_match || last_match) {
                        Slic3r::Point pt = first_match?l.line.first_point():l.line.last_point();
                        perimeter_lines.insert({perim_line_num, {line_num, first_match, pt}});
                        //ROS_INFO_STREAM("Perim seg:" << perim_line_num << ", line num:" << line_num << ", first:" << first_match << ", last:" << last_match);
                    }
                line_num++;
            }
            perim_line_num++;
        }
        perimeters_lines.push_back(perimeter_lines);
    }
    //ROS_INFO_STREAM("Perimeters map created, " << perimeters_lines.size() << " items" );

    Slic3r::Polyline search_line;
    Slic3r::Point last_point_output;
    int search_line_index = -1;
    for(int v=0;v<lines.size();v++) {
        if(lines[v].available) {
            search_line = lines[v].line;
            last_point_output = lines[v].line.first_point(); //don't want to reverse first line
            search_line_index = v;
            //ROS_INFO_STREAM("First search line set, index:" << v);
            break;
        }
    }
    double min_area_X = search_line.last_point().x, max_area_X= search_line.first_point().x;
    

    ROS_INFO_STREAM("Processing fill lines");
    while(search_line_index>=0) {
        double dist_first = last_point_output.distance_to(search_line.first_point());
        double dist_last = last_point_output.distance_to(search_line.last_point());
        //ROS_INFO_STREAM("Starting new output line:" << search_line_index << 
        //        ", Dist to first:" << unscale(dist_first) << ", Dist to last:" << unscale(dist_last) << "----------------------------------------");
        if(dist_first > dist_last)
            search_line.reverse();
        auto search_point = search_line.last_point();
        
        Slic3r::Polyline output_line;
        output_line.append(search_line);
        lines[search_line_index].available = false;

        double minX = INT_MAX, maxX= INT_MIN;
        while(true) {
            int closest_line_index;
            std::multimap<int, perim_points_struct> perimeter;
            Slic3r::Polygon perimeter_points;
            
            int start_transition_index, end_transition_index;
            //find index of perimeter line that intersects search line
            //ROS_INFO_STREAM("Searching for perimeter on start line, index:" << search_line_index);
            bool perimeter_found = false;
            for(int i=0;(i<perimeters_lines.size()) && !perimeter_found;i++) {
                for(auto &p: perimeters_lines[i]) {
                    if((p.second.match_point.distance_to(search_point) < SEARCH_TOLERANCE) && (p.second.line_index == search_line_index)) {
                        perimeter = perimeters_lines[i];
                        perimeter_points = perimeters[i];
                        start_transition_index = p.first;
                        //ROS_INFO_STREAM("Start index found, perimeter:" << i << ", perimeter index:" << start_transition_index);
                        perimeter_found = true;
                        break;
                    }
                }
            }
            
            if(!perimeter_found) {
                //ROS_INFO_STREAM("No matching perimeter found, moving to next line");
                reordered_lines.push_back(output_line);
                last_point_output = output_line.last_point();
                break; //move to next line
            }

            //scan round perimeter to next fill line
            int search_increment = (search_line.last_point().x > search_line.first_point().x)?1 :-1;
            bool found_line = false;
            int index = start_transition_index;
            bool closest_line_needs_reversing = false;
            for(int i=0;(i<20) && !found_line;i++) {
                auto range = perimeter.equal_range(index);
                for(auto iter=range.first;(iter!=range.second) && !found_line;iter++) {
                    if(lines[iter->second.line_index].available) {
                        if((lines[iter->second.line_index].line.first_point().y >= search_point.y) && 
                                    (lines[iter->second.line_index].line.first_point().y < (search_point.y + scale_(req.distance + 0.005)))) {
                            end_transition_index = index;
                            closest_line_index = iter->second.line_index;
                            if(!iter->second.first_match) //can't actually reverse here as line may be binned if reordering needed
                                closest_line_needs_reversing = true; //and revrsing would mess up lookups so just flag
                            found_line = true;
                            //ROS_INFO_STREAM("Found match on perimeter index:" << end_transition_index << ", line index:" << 
                            //            closest_line_index <<  ", Reversed:" << !iter->second.first_match);
                        }
                    }
                }
                index+=search_increment;
                if(index >= perimeter_points.lines().size())
                    index = 0;
                if(index < 0)
                    index = perimeter_points.lines().size()-1;
            }
            
            Slic3r::Polyline transition_line;
            if(found_line) {
                //ROS_INFO_STREAM("Appending line--------------------------------------------------------");
                bool add_line = true;
                int start=0, end=0;
                if(start_transition_index != end_transition_index) {
                    if(search_increment>0) { //forwards
                        start = start_transition_index + 1;//only want last line point on start line
                        if(start >= perimeter_points.points.size()) start = 0;
                        end = end_transition_index;
                    } else {
                        start = start_transition_index;//only want last line point on start line
                        end = end_transition_index + 1;
                        if(end >= perimeter_points.points.size()) end = 0;
                    }
                    //ROS_INFO_STREAM("Outputing perimeter points from index:" << start << ", to:" << end);
                    while(true) {
                        Slic3r::coord_t pp_s_y = perimeter_points.points[start].y;
                        Slic3r::coord_t sp_s_y_min = (search_point.y - scale_(req.distance - 0.005));
                        Slic3r::coord_t sp_s_y_max = (search_point.y + scale_(req.distance + 0.005));
                        //ROS_INFO_STREAM("pp y:" << unscale(pp_s_y) << ", sp y_min:" << unscale(sp_s_y_min) << ", sp y_max:" << unscale(sp_s_y_max));
                        if((pp_s_y < sp_s_y_min) || (pp_s_y > sp_s_y_max)) {
                            add_line = false;
                            break;
                        }
                        transition_line.append(perimeter_points.points[start]);
                        if(start==end) {
                            break;
                        } else {
                            start = start + search_increment;
                            if(start < 0) start = perimeter_points.points.size() -1;
                            if(start >= perimeter_points.points.size()) start = 0;
                        }
                    }
                }
                if(add_line) {
                    //need to check whether reordering is needed
                    bool split = false;
                    if(req.reorder_fill) {
                        for (int sli=0; sli<lines.size();sli++) {
                            if(lines[sli].available && (sli < closest_line_index) &&
                                    (lines[closest_line_index].line.first_point().y > (lines[sli].line.first_point().y + SEARCH_TOLERANCE)) && 
                                    (((minX <= lines[sli].line.first_point().x) && (maxX >= lines[sli].line.first_point().x)) || 
                                    ((minX <= lines[sli].line.last_point().x) && (maxX >= lines[sli].line.last_point().x))))
                                split = true;
                        }
                    }
                    if(split) {
                        //ROS_INFO_STREAM("Output line due to reorder********************************************");
                        reordered_lines.push_back(output_line);
                        last_point_output = output_line.last_point();
                        break;
                    } else {
                        //ROS_INFO_STREAM("Merging line");
                        Slic3r::Polyline line_to_output = lines[closest_line_index].line;
                        if(closest_line_needs_reversing)
                            line_to_output.reverse();
                        Slic3r::coord_t first_pt_x = line_to_output.first_point().x;
                        Slic3r::coord_t last_pt_x = line_to_output.last_point().x;
                        minX = first_pt_x < last_pt_x?first_pt_x:last_pt_x;
                        maxX = first_pt_x >= last_pt_x?first_pt_x:last_pt_x;
                        if(minX < min_area_X) min_area_X = minX;
                        if(maxX > max_area_X) max_area_X = maxX;
                        output_line.append(transition_line);
                        output_line.append(line_to_output);
                        search_line = line_to_output;
                        search_line_index = closest_line_index;
                        search_point = search_line.last_point();
                        lines[closest_line_index].available = false;
                    }
                } else {
                    //ROS_INFO_STREAM("Merged cancelled due to perimeter excursion, start:" << start << ", end:" << end << ", size:" << perimeter_points.points.size());
                    reordered_lines.push_back(output_line);
                    last_point_output = output_line.last_point();
                    //ROS_INFO_STREAM("Output line***********************************************************");
                    break;
                }
            }
            else {
                reordered_lines.push_back(output_line);
                last_point_output = output_line.last_point();
                //ROS_INFO_STREAM("Output line due to no match found*************************************");
                break;
            }
        }
        //do we have another line to process
        search_line_index = -1;
        //first look for lines that fall into shadow of already mowed
        for(int v=0;v<lines.size();v++) {
            if(lines[v].available) {
                auto eq_points = lines[v].line.equally_spaced_points(scale_(0.5));
                for(auto &pt: eq_points) {
                    if(((pt.x > min_area_X) && (pt.x < max_area_X))) {
                        search_line = lines[v].line;
                        search_line_index = v;
                        goto POINT_IN_SHADOW;
                    }
                }
            }
        }
        POINT_IN_SHADOW:
        //if not found look through all lines
        if(search_line_index<0) {
            for(int v=0;v<lines.size();v++) {
                if(lines[v].available) {
                    search_line = lines[v].line;
                    search_line_index = v;
                    break;
                }
            }
        }
    }

    //rotate back to correct angle
    for(auto &ln: reordered_lines) {
        ln.rotate(-rot_angle, origin);
    }

    ROS_INFO_STREAM("Join complete");
    //return fill_lines;
    return reordered_lines;
}


bool planPath(slic3r_coverage_planner::PlanPathRequest &req, slic3r_coverage_planner::PlanPathResponse &res) {

    Slic3r::Polygon outline_poly;
    //Slic3r::Point start_point = req.outline.points[0];
    Slic3r::Point start_point(req.outline.points[0].x, req.outline.points[0].y);
    for (auto &pt: req.outline.points) {
        outline_poly.points.push_back(Point(scale_(pt.x), scale_(pt.y)));
    }

    outline_poly.make_counter_clockwise();

    // This ExPolygon contains our input area with holes.
    Slic3r::ExPolygon expoly(outline_poly);

    for (auto &hole: req.holes) {
        Slic3r::Polygon hole_poly;
        for (auto &pt: hole.points) {
            hole_poly.points.push_back(Point(scale_(pt.x), scale_(pt.y)));
        }
        hole_poly.make_clockwise();

        expoly.holes.push_back(hole_poly);
    }

    // Results are stored here
    std::vector<Polygons> area_outlines;
    Polylines fill_lines;
    std::vector<Polygons> obstacle_outlines;


    coord_t distance = scale_(req.distance);
    coord_t outer_distance = scale_(req.outer_offset);

    // detect how many perimeters must be generated for this island
    int loops = req.outline_count;

    ROS_INFO_STREAM("generating " << loops << " outlines");

    const int loop_number = loops - 1;  // 0-indexed loops
    const int inner_loop_number = loop_number - req.outline_overlap_count;


    Polygons gaps;

    Polygons last = expoly;
    Polygons inner = last;
    if (loop_number >= 0) {  // no loops = -1

        std::vector<PerimeterGeneratorLoops> contours(loop_number + 1);    // depth => loops
        std::vector<PerimeterGeneratorLoops> holes(loop_number + 1);       // depth => loops

        for (int i = 0; i <= loop_number; ++i) {  // outer loop is 0
            Polygons offsets;

            if (i == 0) {
                offsets = offset(
                        last,
                        -outer_distance
                );
            } else {
                offsets = offset(
                        last,
                        -distance
                );
            }

            if (offsets.empty()) break;


            last = offsets;
            if (i <= inner_loop_number) {
                inner = last;
            }

            for (Polygons::const_iterator polygon = offsets.begin(); polygon != offsets.end(); ++polygon) {
                PerimeterGeneratorLoop loop(*polygon, i);
                loop.is_contour = polygon->is_counter_clockwise();
                if (loop.is_contour) {
                    contours[i].push_back(loop);
                } else {
                    holes[i].push_back(loop);
                }
            }
        }

        // nest loops: holes first
        for (int d = 0; d <= loop_number; ++d) {
            PerimeterGeneratorLoops &holes_d = holes[d];

            // loop through all holes having depth == d
            for (int i = 0; i < (int) holes_d.size(); ++i) {
                const PerimeterGeneratorLoop &loop = holes_d[i];

                // find the hole loop that contains this one, if any
                for (int t = d + 1; t <= loop_number; ++t) {
                    for (int j = 0; j < (int) holes[t].size(); ++j) {
                        PerimeterGeneratorLoop &candidate_parent = holes[t][j];
                        if (candidate_parent.polygon.contains(loop.polygon.first_point())) {
                            candidate_parent.children.push_back(loop);
                            holes_d.erase(holes_d.begin() + i);
                            --i;
                            goto NEXT_LOOP;
                        }
                    }
                }

                NEXT_LOOP:;
            }
        }

        // nest contour loops
        for (int d = loop_number; d >= 1; --d) {
            PerimeterGeneratorLoops &contours_d = contours[d];

            // loop through all contours having depth == d
            for (int i = 0; i < (int) contours_d.size(); ++i) {
                const PerimeterGeneratorLoop &loop = contours_d[i];

                // find the contour loop that contains it
                for (int t = d - 1; t >= 0; --t) {
                    for (size_t j = 0; j < contours[t].size(); ++j) {
                        PerimeterGeneratorLoop &candidate_parent = contours[t][j];
                        if (candidate_parent.polygon.contains(loop.polygon.first_point())) {
                            candidate_parent.children.push_back(loop);
                            contours_d.erase(contours_d.begin() + i);
                            --i;
                            goto NEXT_CONTOUR;
                        }
                    }
                }

                NEXT_CONTOUR:;
            }
        }

        traverse_from_right(contours[0], area_outlines);
        for (auto &hole: holes) {
            traverse_from_left(hole, obstacle_outlines);
        }

        for (auto &obstacle_group: obstacle_outlines) {
            for (auto &poly: obstacle_group) {
                std::reverse(poly.points.begin(), poly.points.end());
            }
        }
    }


    ExPolygons expp = union_ex(inner);


    // Go through the innermost poly and create the fill path using a Fill object
    for (auto &poly: expp) {
        Slic3r::Surface surface(Slic3r::SurfaceType::stBottom, poly);


        Slic3r::Fill *fill;
        if (req.fill_type == slic3r_coverage_planner::PlanPathRequest::FILL_LINEAR) {
            fill = new Slic3r::FillRectilinear();
        } else {
            fill = new Slic3r::FillConcentric();
        }
        fill->link_max_length = scale_(1.0);
        fill->angle = req.angle;
        fill->z = scale_(1.0);
        fill->endpoints_overlap = 0;
        fill->density = 1.0;
        fill->dont_connect = !req.use_slic3r_Joining;
        fill->dont_adjust = false;
        fill->min_spacing = req.distance;
        fill->complete = false;
        fill->link_max_length = 0;

        ROS_INFO_STREAM("Starting Fill. Poly size:" << surface.expolygon.contour.points.size());

        Slic3r::Polylines lines = fill->fill_surface(surface);
        append_to(fill_lines, lines);
        delete fill;
        fill = nullptr;

        ROS_INFO_STREAM("Fill Complete. Polyline count: " << lines.size());
        for (int i = 0; i < lines.size(); i++) {
            ROS_INFO_STREAM("Polyline " << i << " has point count: " << lines[i].points.size());
        }
    }


    std_msgs::Header header;
    header.stamp = ros::Time::now();
    header.frame_id = "map";
    header.seq = 0;

    Point areaLastPoint;
    bool areaLastPointValid = false;
    for (auto &group: area_outlines) {
        areaLastPointValid = false;
        auto path = determinePathForOutline(header, outline_poly, group, false, start_point, &areaLastPoint, &areaLastPointValid);
        res.paths.push_back(path);
    }

    // The order for 3d printing seems to be to sweep across the X and then up the Y axis
    // which is very inefficient for a mower. Order the holes by distance to the previous end-point instead.
    std::vector<Slic3r::Polygons> ordered_obstacle_outlines;
    {
        auto prev_point = areaLastPoint;
        if (!areaLastPointValid && obstacle_outlines.size() > 0) {
            // If no prev point set to the first point in first obstacle
            // Note: back() polygon is the first (outer) loop
            prev_point = obstacle_outlines.front().back().points.front();
        }
        while (obstacle_outlines.size()) {
            // Sort be desc distance then pop closest outline from the back of the vector
            std::sort(obstacle_outlines.begin(), obstacle_outlines.end(),
                      [prev_point](Slic3r::Polygons &a, Slic3r::Polygons &b) {
                          // Note: back() polygon is the first (outer) loop
                          auto a_firstPoint = a.back().points.front();
                          double distance_a = sqrt(
                                  (a_firstPoint.x - prev_point.x) * (a_firstPoint.x - prev_point.x) +
                                  (a_firstPoint.y - prev_point.y) * (a_firstPoint.y - prev_point.y)
                          );
                          auto b_firstPoint = b.back().points.front();
                          double distance_b = sqrt(
                                  (b_firstPoint.x - prev_point.x) * (b_firstPoint.x - prev_point.x) +
                                  (b_firstPoint.y - prev_point.y) * (b_firstPoint.y - prev_point.y)
                          );
                          return distance_a >= distance_b;
                      });
            ordered_obstacle_outlines.push_back(obstacle_outlines.back());
            obstacle_outlines.pop_back();
            // Note: front() polygon is the last (inner) loop
            prev_point = ordered_obstacle_outlines.back().front().points.back();
        }
    }

    // At this point, the obstacles outlines are still "the wrong way" (i.e. inner first, then outer ...),
    // this is intentional, because then it's easier to find good traversal points.
    // In order to make the mower approach the obstacle, we will reverse the path later.
    for (auto &group: ordered_obstacle_outlines) {
        areaLastPointValid = false;
        auto path = determinePathForOutline(header, outline_poly, group, true, start_point, &areaLastPoint, &areaLastPointValid);  
        res.paths.push_back(path);
    }

    if(req.use_slic3r_Joining == false) {
        ROS_INFO_STREAM("Using custom line joining algorithm" );
        if(req.reorder_fill && req.priority_reorder) {
            ROS_INFO_STREAM("Processing priority areas and joining lines" );
            auto priority_lines = extract_lines(req, &fill_lines);
            priority_lines = join_fill_lines(req, inner, priority_lines, true);
            fill_lines = join_fill_lines(req, inner, fill_lines, false);
            append_to(priority_lines, fill_lines);
            fill_lines = priority_lines;
        } else {
            ROS_INFO_STREAM("Joining lines" );
            fill_lines = join_fill_lines(req, inner, fill_lines, false);
        }
    }
    else ROS_INFO_STREAM("Slic3r line joining used" );
    ROS_INFO_STREAM("Splitting complete, got " << fill_lines.size() << " lines:" );

    double smooth_clip_first_pass = int(950.0*req.distance/3.0)/1000.0;
    double smooth_clip_second_pass = int(950.0*req.distance/9.0)/1000.0;
    for (int i = 0; i < fill_lines.size(); i++) {
        auto &line = fill_lines[i];
        slic3r_coverage_planner::Path path;
        path.is_outline = false;
        path.path.header = header;

        line.remove_duplicate_points();

        line = smooth_polyline(smooth_polyline(line, scale_(smooth_clip_first_pass)), scale_(smooth_clip_second_pass));

        auto equally_spaced_points = sparse_spaced_points(line, scale_(0.04));
        if (equally_spaced_points.size() < 2) {
            ROS_INFO("Skipping single dot");
            continue;
        }
        ROS_INFO_STREAM("Got " << equally_spaced_points.size() << " points");

        Point *lastPoint = nullptr;
        for (auto &pt: equally_spaced_points) {
            if (lastPoint == nullptr) {
                lastPoint = &pt;
                continue;
            }

            // calculate pose for "lastPoint" pointing to current point

            auto dir = pt - *lastPoint;
            double orientation = atan2(dir.y, dir.x);
            tf2::Quaternion q(0.0, 0.0, orientation);

            geometry_msgs::PoseStamped pose;
            pose.header = header;
            pose.pose.orientation = tf2::toMsg(q);
            pose.pose.position.x = unscale(lastPoint->x);
            pose.pose.position.y = unscale(lastPoint->y);
            pose.pose.position.z = 0;
            path.path.poses.push_back(pose);
            lastPoint = &pt;
        }

        // finally, we add the final pose for "lastPoint" with the same orientation as the last poe
        geometry_msgs::PoseStamped pose;
        pose.header = header;
        pose.pose.orientation = path.path.poses.back().pose.orientation;
        pose.pose.position.x = unscale(lastPoint->x);
        pose.pose.position.y = unscale(lastPoint->y);
        pose.pose.position.z = 0;
        path.path.poses.push_back(pose);

        res.paths.push_back(path);
    }

    if (visualize_plan) {
        visualization_msgs::MarkerArray arr;
        {
            visualization_msgs::Marker marker;

            marker.header.frame_id = "map";
            marker.ns = "mower_map_service_lines";
            marker.id = -1;
            marker.frame_locked = true;
            marker.action = visualization_msgs::Marker::DELETEALL;
            arr.markers.push_back(marker);
        }
        createMarkers(req, res, arr);
        marker_array_publisher.publish(arr);
    }


    return true;
}


int main(int argc, char **argv) {
    ros::init(argc, argv, "slic3r_coverage_planner");

    ros::NodeHandle n;
    ros::NodeHandle paramNh("~");

    visualize_plan = paramNh.param("visualize_plan", true);

    if (visualize_plan) {
        marker_array_publisher = n.advertise<visualization_msgs::MarkerArray>(
                "slic3r_coverage_planner/path_marker_array", 100, true);
    }

    if(!paramNh.getParam("transition_distance_m",transition_distance_m)) {
        double wheel_distance_m = 0.0;
        if(paramNh.getParam("wheel_distance_m",wheel_distance_m)) {
            transition_distance_m = 3 * wheel_distance_m;
        } else {
            transition_distance_m = 3 * 0.325;
        }
    }

    if(!paramNh.getParam("use_linear_transition",use_linear_transition)) {
        use_linear_transition = false;
    }

    ros::ServiceServer plan_path_srv = n.advertiseService("slic3r_coverage_planner/plan_path", planPath);

    ros::spin();
    return 0;
}
