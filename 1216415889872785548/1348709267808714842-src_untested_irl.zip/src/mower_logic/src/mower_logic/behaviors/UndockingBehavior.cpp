// Created by Clemens Elflein on 2/21/22.
// Copyright (c) 2022 Clemens Elflein. All rights reserved.
//
// This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
//
// Feel free to use the design in your private/educational projects, but don't try to sell the design or products based on it without getting my consent first.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
//
#include "UndockingBehavior.h"
#include "tf2_eigen/tf2_eigen.h"
#include "mower_map/PersistNextGlobalPlanSrv.h"

extern ros::ServiceClient dockingPointClient;
extern ros::ServiceClient persistGPlanClient;
extern actionlib::SimpleActionClient<mbf_msgs::ExePathAction> *mbfClientExePath;
extern xbot_msgs::AbsolutePose getPose();
extern mower_msgs::Status getStatus();

extern void setRobotPose(geometry_msgs::Pose &pose);
extern void stopMoving();
extern bool isGpsGood();
extern bool setGPS(bool enabled);

UndockingBehavior UndockingBehavior::INSTANCE(&MowingBehavior::INSTANCE);
UndockingBehavior UndockingBehavior::RETRY_INSTANCE(&DockingBehavior::INSTANCE);

std::string UndockingBehavior::state_name() {
    return "UNDOCKING";
}

Behavior *UndockingBehavior::execute() {

    static bool seedRqd = true;

    // get robot's current pose from odometry.
    xbot_msgs::AbsolutePose pose = getPose();
    tf2::Quaternion quat;
    tf2::fromMsg(pose.pose.pose.orientation, quat);
    tf2::Matrix3x3 m(quat);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);

    mbf_msgs::ExePathGoal exePathGoal;

    nav_msgs::Path path;

    geometry_msgs::PoseStamped docking_pose_stamped_front;
    docking_pose_stamped_front.pose = pose.pose.pose;
    docking_pose_stamped_front.header = pose.header;   

    ROS_INFO_STREAM("Undock start pose - X:" << docking_pose_stamped_front.pose.position.x << ", Y:" << docking_pose_stamped_front.pose.position.y);   

    int undock_point_count = 3;
    double incremental_distance = config.undock_distance/undock_point_count;
    path.poses.push_back(docking_pose_stamped_front); //start from current position
    for (int i = 0; i < undock_point_count; i++) {      
        docking_pose_stamped_front.pose.position.x -= cos(yaw) * incremental_distance;
        docking_pose_stamped_front.pose.position.y -= sin(yaw) * incremental_distance;
        path.poses.push_back(docking_pose_stamped_front);
    }

    ROS_INFO_STREAM("Undock stage 1 end pose - X:" << docking_pose_stamped_front.pose.position.x << ", Y:" << docking_pose_stamped_front.pose.position.y);

    double angle;
    if(config.undock_fixed_angle) {
        angle = config.undock_angle * (M_PI+M_PI)/360.0;
        ROS_INFO_STREAM("Fixed angle undock: " << config.undock_angle);
    }
    else {
        //seed based on first undock time rather than boot so should be ok even without RTC
        if(seedRqd) {
            srand(ros::Time::now().toSec()); 
            ROS_INFO_STREAM("Random angle undock: Seeded rand()");
            seedRqd = false;
        }
        double ranNum = (((((double)rand())/RAND_MAX) - 0.5) * 2.0);
        double ranAngle = abs(config.undock_angle) * ranNum;
        ROS_INFO_STREAM("Random angle undock: " << ranAngle);
        angle = ranAngle * (M_PI+M_PI)/360.0;
    }

    undock_point_count = 10;
    incremental_distance = config.undock_angled_distance/undock_point_count;
    for (int i = 0; i < undock_point_count; i++) {
        double orientation = yaw + (angle * (config.undock_use_curve ? (((double)i + 1.0) / undock_point_count) : 1.0));
        docking_pose_stamped_front.pose.position.x -= cos(orientation) * incremental_distance;
        docking_pose_stamped_front.pose.position.y -= sin(orientation) * incremental_distance;

        tf2::Quaternion q;
        q.setRPY(0.0, 0.0, orientation);
        docking_pose_stamped_front.pose.orientation = tf2::toMsg(q);
        path.poses.push_back(docking_pose_stamped_front);
    }

    ROS_INFO_STREAM("Undock end pose - X:" << docking_pose_stamped_front.pose.position.x << ", Y:" << docking_pose_stamped_front.pose.position.y);

/*    next_undock_angle = angle + ((abs(config.undock_angle) * (M_PI+M_PI)/360.0)/4.0);
    if(next_undock_angle > abs(config.undock_angle) * (M_PI+M_PI)/360.0)
        next_undock_angle = -abs(config.undock_angle) * (M_PI+M_PI)/360.0;*/
    
    exePathGoal.path = path;
    exePathGoal.angle_tolerance = 1.0 * (M_PI / 180.0);
    exePathGoal.dist_tolerance = 0.1;
    exePathGoal.tolerance_from_action = true;
    exePathGoal.controller = "DockingFTCPlanner";

    auto result = mbfClientExePath->sendGoalAndWait(exePathGoal);

    bool success = result.state_ == actionlib::SimpleClientGoalState::SUCCEEDED;

    // stop the bot for now
    stopMoving();

    if (!success) {
        ROS_ERROR_STREAM("Error during undock");
        return &IdleBehavior::INSTANCE;
    }

    mower_map::PersistNextGlobalPlanSrv persist_plan_srv;
    persist_plan_srv.request.persist = true;
    persistGPlanClient.call(persist_plan_srv);

    ROS_INFO_STREAM("Undock success. Waiting for GPS.");
    bool hasGps = waitForGPS();

    if (!hasGps) {
        ROS_ERROR_STREAM("Could not get GPS.");
        return &IdleBehavior::INSTANCE;
    }

    // TODO return mow area
    return nextBehavior;

}

void UndockingBehavior::enter() {
    reset();
    paused = aborted = false;

    // Get the docking pose in map
    mower_map::GetDockingPointSrv get_docking_point_srv;
    dockingPointClient.call(get_docking_point_srv);
    docking_pose_stamped.pose = get_docking_point_srv.response.docking_pose;
    ROS_INFO_STREAM("Currently inside the docking station, got docks pose.");
    ROS_INFO_STREAM("X:" << docking_pose_stamped.pose.position.x << ", Y:" << docking_pose_stamped.pose.position.y);

    // Compensate for straight path docking move length   
    tf2::Quaternion quat;
    tf2::fromMsg(docking_pose_stamped.pose.orientation, quat);
    tf2::Matrix3x3 m(quat);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);
    docking_pose_stamped.pose.position.x += cos(yaw) * config.docking_distance;
    docking_pose_stamped.pose.position.y += sin(yaw) * config.docking_distance;
    ROS_INFO_STREAM("Currently inside the docking station, compensated for docking distance of:" << config.docking_distance);
    ROS_INFO_STREAM("X:" << docking_pose_stamped.pose.position.x << ", Y:" << docking_pose_stamped.pose.position.y);

    docking_pose_stamped.header.frame_id = "map";
    docking_pose_stamped.header.stamp = ros::Time::now();

    // set the robot's position to the dock if we're actually docked
    if(getStatus().v_charge > 5.0) {
        ROS_INFO_STREAM("Currently inside the docking station, we set the robot's pose to the docks pose.");
        setRobotPose(docking_pose_stamped.pose);
    }
}

void UndockingBehavior::exit() {

}

void UndockingBehavior::reset() {
    gpsRequired = false;
}

bool UndockingBehavior::needs_gps() {
    return gpsRequired;
}

bool UndockingBehavior::mower_enabled() {
    // No mower during docking
    return false;
}

bool UndockingBehavior::waitForGPS() {
    gpsRequired = false;
    setGPS(true);
    ros::Rate odom_rate(1.0);
    while (ros::ok() && !aborted) {
        if (isGpsGood()) {
            ROS_INFO("Got good gps, let's go");
            break;
        } else {
            ROS_INFO_STREAM("waiting for gps. current accuracy: " << getPose().position_accuracy);
            odom_rate.sleep();
        }
    }
    if (!ros::ok() || aborted) {
        return false;
    }

    // wait additional time for odometry filters to converge
    ros::Rate r(ros::Duration(config.gps_wait_time, 0));
    r.sleep();

    gpsRequired = true;

    return true;
}

UndockingBehavior::UndockingBehavior(Behavior* next) {
    this->nextBehavior = next;
}

void UndockingBehavior::command_home() {

}

void UndockingBehavior::command_start() {

}

void UndockingBehavior::command_s1() {

}

void UndockingBehavior::command_s2() {

}

bool UndockingBehavior::redirect_joystick() {
    return false;
}


uint8_t UndockingBehavior::get_sub_state() {
    return 2;

}
uint8_t UndockingBehavior::get_state() {
    return mower_msgs::HighLevelStatus::HIGH_LEVEL_STATE_AUTONOMOUS;
}

void UndockingBehavior::handle_action(std::string action) {
}
