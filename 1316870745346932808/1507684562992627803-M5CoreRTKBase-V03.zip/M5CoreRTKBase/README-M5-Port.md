# M5Core RTK Base - minimal ESP32-XBee port

This ZIP is a clean PlatformIO/ESP-IDF project based on esp32-xbee, with only the minimal M5Stack Core hardware changes applied:

- GNSS UART moved to UART2: TX GPIO17, RX GPIO16.
- RTS/CTS disabled.
- Original ESP32-XBee LED driver replaced with no-op functions.
- Reset/config button changed from the ESP32 boot button to M5Stack Button A GPIO39.
- Original `www` SPIFFS files and `partitions.csv` restored.

Build/upload from PlatformIO:

```powershell
pio run
pio run -t upload
pio run -t uploadfs
pio device monitor
```

If changing partitions on a board that was already flashed:

```powershell
pio run -t erase
pio run -t upload
pio run -t uploadfs
```


## v04 build fixes

This version adds the ESP-IDF v5 external mDNS component dependency, fixes missing standard includes in `status_led.h`, and replaces the old non-constant IP initializer expressions in `config.c` with compile-time constants.


## v05 build notes

For the initial PlatformIO / ESP-IDF 5.5 M5Stack Core bring-up:

- `interface/ntrip2_client.c` and `interface/ntrip2_server.c` are not built. They depend on old/incomplete UART handler symbols and are not declared in the public NTRIP header or initialized by `main.c`.
- AP forwarding/NAPT is disabled to avoid the old `ip_napt_enable()` dependency during first bring-up.
- Hotspot-only web authentication is temporarily permissive because the original AP station-list API/header is not available in this PlatformIO ESP-IDF 5.5 package. Use basic auth if the web UI is exposed beyond a private test network.
- The normal NTRIP client, NTRIP server, NTRIP caster, socket client/server, Wi-Fi, UART, and web server sources are still built.
