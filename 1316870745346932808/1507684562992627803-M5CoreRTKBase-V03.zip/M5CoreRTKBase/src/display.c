#include "display.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <driver/gpio.h>
#include <driver/ledc.h>
#include <driver/spi_master.h>
#include <esp_err.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <esp_netif_ip_addr.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "interface/ntrip.h"
#include "stream_stats.h"
#include "wifi.h"
#include "tasks.h"

static const char *TAG = "DISPLAY";

#define LCD_HOST SPI3_HOST

#define LCD_PIN_MISO 19
#define LCD_PIN_MOSI 23
#define LCD_PIN_CLK  18
#define LCD_PIN_CS   14
#define LCD_PIN_DC   27
#define LCD_PIN_RST  33
#define LCD_PIN_BL   32
#define LCD_BACKLIGHT_LEDC_MODE LEDC_LOW_SPEED_MODE
#define LCD_BACKLIGHT_LEDC_TIMER LEDC_TIMER_0
#define LCD_BACKLIGHT_LEDC_CHANNEL LEDC_CHANNEL_0
#define LCD_BACKLIGHT_LEDC_DUTY_MAX 8191
#define LCD_BACKLIGHT_PERCENT 40

#define LCD_WIDTH  320
#define LCD_HEIGHT 240

/* ILI9341 MADCTL. 0xA8 is the alternate M5Stack Core landscape orientation. */
#define LCD_MADCTL_VALUE 0x08

#define COLOR_BG      0x18E3  /* VS Code-ish #1E1E1E. */
#define COLOR_PANEL   0x2104  /* Slightly lighter dark row background. */
#define COLOR_TITLE   0x87F0  /* Muted cyan/green. */
#define COLOR_TEXT    0xD69A  /* Soft off-white. */
#define COLOR_MUTED   0x8410
#define COLOR_ACCENT  0x6D9F
#define COLOR_WARN    0xFDE0

#define FONT_WIDTH    5U
#define FONT_HEIGHT   7U
#define FONT_SPACING  1U
#define TEXT_SCALE    2U
#define ROW_HEIGHT    20U
#define ROW_BUFFER_HEIGHT 20U

static spi_device_handle_t lcd_spi;
static bool display_ready;

static uint16_t row_buffer[LCD_WIDTH * ROW_BUFFER_HEIGHT];

static void display_task(void *ctx);
static esp_err_t lcd_write_command(uint8_t command);
static esp_err_t lcd_write_data(const void *data, int len);
static void lcd_reset();
static void lcd_backlight_init();
static void lcd_init_panel();
static void lcd_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
static void lcd_fill_screen(uint16_t color);
static void row_clear(uint16_t height, uint16_t color);
static void row_draw_pixel_block(uint16_t x, uint16_t y, uint8_t scale, uint16_t height, uint16_t color);
static void row_draw_char(uint16_t x, uint16_t y, char c, uint8_t scale, uint16_t height, uint16_t color);
static void row_draw_text(uint16_t x, uint16_t y, const char *text, uint8_t scale, uint16_t height, uint16_t color);
static void lcd_write_row(uint16_t x, uint16_t y, uint16_t w, uint16_t h);
static void draw_text_row(uint16_t y, const char *text, uint16_t color, uint16_t bg);
static const uint8_t *font_for_char(char c);
static void ip_to_text(char *buffer, size_t buffer_size, esp_ip4_addr_t addr, bool valid);
static void age_to_text(char *buffer, size_t buffer_size, uint32_t now_ms, uint32_t event_ms);
static void time_to_text(char *buffer, size_t buffer_size);



void display_init()
{
    gpio_config_t lcd_gpio_config = {
            .pin_bit_mask = (1ULL << LCD_PIN_DC) | (1ULL << LCD_PIN_RST),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE
    };
    ESP_ERROR_CHECK(gpio_config(&lcd_gpio_config));

    //gpio_set_level(LCD_PIN_BL, 0);

    spi_bus_config_t bus_config = {
            .mosi_io_num = LCD_PIN_MOSI,
            .miso_io_num = LCD_PIN_MISO,
            .sclk_io_num = LCD_PIN_CLK,
            .quadwp_io_num = -1,
            .quadhd_io_num = -1,
            .max_transfer_sz = LCD_WIDTH * ROW_BUFFER_HEIGHT * sizeof(uint16_t)
    };

    esp_err_t err = spi_bus_initialize(LCD_HOST, &bus_config, SPI_DMA_CH_AUTO);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "SPI bus init failed: %s", esp_err_to_name(err));
        return;
    }

    spi_device_interface_config_t dev_config = {
            .clock_speed_hz = 40000000,
            .mode = 0,
            .spics_io_num = LCD_PIN_CS,
            .queue_size = 3
    };

    err = spi_bus_add_device(LCD_HOST, &dev_config, &lcd_spi);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "LCD SPI device init failed: %s", esp_err_to_name(err));
        return;
    }

    lcd_reset();
    lcd_init_panel();
    //gpio_set_level(LCD_PIN_BL, 1);
    lcd_backlight_init();

    display_ready = true;
    lcd_fill_screen(COLOR_BG);
    draw_text_row(8, "M5CORE RTK BASE", COLOR_TITLE, COLOR_BG);
    draw_text_row(34, "DISPLAY STARTING", COLOR_TEXT, COLOR_BG);

    xTaskCreate(display_task, "display_task", 6144, NULL, TASK_PRIORITY_DISPLAY, NULL);
}

static esp_err_t lcd_write_command(uint8_t command)
{
    gpio_set_level(LCD_PIN_DC, 0);
    spi_transaction_t transaction = {
            .length = 8,
            .tx_buffer = &command
    };
    return spi_device_transmit(lcd_spi, &transaction);
}

static esp_err_t lcd_write_data(const void *data, int len)
{
    if (len <= 0) return ESP_OK;

    gpio_set_level(LCD_PIN_DC, 1);
    spi_transaction_t transaction = {
            .length = len * 8,
            .tx_buffer = data
    };
    return spi_device_transmit(lcd_spi, &transaction);
}

static void lcd_reset()
{
    gpio_set_level(LCD_PIN_RST, 0);
    vTaskDelay(pdMS_TO_TICKS(50));
    gpio_set_level(LCD_PIN_RST, 1);
    vTaskDelay(pdMS_TO_TICKS(120));
}

static void lcd_backlight_init()
{
    ledc_timer_config_t timer_config = {
            .speed_mode = LCD_BACKLIGHT_LEDC_MODE,
            .duty_resolution = LEDC_TIMER_13_BIT,
            .timer_num = LCD_BACKLIGHT_LEDC_TIMER,
            .freq_hz = 5000,
            .clk_cfg = LEDC_AUTO_CLK
    };

    ESP_ERROR_CHECK(ledc_timer_config(&timer_config));

    ledc_channel_config_t channel_config = {
            .gpio_num = LCD_PIN_BL,
            .speed_mode = LCD_BACKLIGHT_LEDC_MODE,
            .channel = LCD_BACKLIGHT_LEDC_CHANNEL,
            .intr_type = LEDC_INTR_DISABLE,
            .timer_sel = LCD_BACKLIGHT_LEDC_TIMER,
            .duty = (LCD_BACKLIGHT_LEDC_DUTY_MAX * LCD_BACKLIGHT_PERCENT) / 100,
            .hpoint = 0
    };

    ESP_ERROR_CHECK(ledc_channel_config(&channel_config));
}

static void lcd_init_panel()
{
    uint8_t data;

    lcd_write_command(0x01);
    vTaskDelay(pdMS_TO_TICKS(120));

    lcd_write_command(0x11);
    vTaskDelay(pdMS_TO_TICKS(120));

    /* M5Stack Core panels normally need display inversion enabled for correct colors. */
    lcd_write_command(0x21);

    data = 0x55;
    lcd_write_command(0x3A);
    lcd_write_data(&data, 1);

    data = LCD_MADCTL_VALUE;
    lcd_write_command(0x36);
    lcd_write_data(&data, 1);

    lcd_write_command(0x29);
    vTaskDelay(pdMS_TO_TICKS(20));
}

static void lcd_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    uint8_t data[4];

    lcd_write_command(0x2A);
    data[0] = x0 >> 8;
    data[1] = x0 & 0xFF;
    data[2] = x1 >> 8;
    data[3] = x1 & 0xFF;
    lcd_write_data(data, sizeof(data));

    lcd_write_command(0x2B);
    data[0] = y0 >> 8;
    data[1] = y0 & 0xFF;
    data[2] = y1 >> 8;
    data[3] = y1 & 0xFF;
    lcd_write_data(data, sizeof(data));

    lcd_write_command(0x2C);
}

static void lcd_fill_screen(uint16_t color)
{
    if (!display_ready) return;

    for (uint32_t i = 0; i < LCD_WIDTH * ROW_BUFFER_HEIGHT; i++) {
        row_buffer[i] = __builtin_bswap16(color);
    }

    lcd_set_window(0, 0, LCD_WIDTH - 1, LCD_HEIGHT - 1);
    for (uint16_t y = 0; y < LCD_HEIGHT; y += ROW_BUFFER_HEIGHT) {
        uint16_t h = (LCD_HEIGHT - y) > ROW_BUFFER_HEIGHT ? ROW_BUFFER_HEIGHT : (LCD_HEIGHT - y);
        lcd_write_data(row_buffer, LCD_WIDTH * h * sizeof(uint16_t));
    }
}

static void row_clear(uint16_t height, uint16_t color)
{
    if (height > ROW_BUFFER_HEIGHT) height = ROW_BUFFER_HEIGHT;
    for (uint32_t i = 0; i < LCD_WIDTH * height; i++) {
        row_buffer[i] = __builtin_bswap16(color);
    }
}

static void row_draw_pixel_block(uint16_t x, uint16_t y, uint8_t scale, uint16_t height, uint16_t color)
{
    if (x >= LCD_WIDTH || y >= height) return;

    uint16_t max_x = x + scale;
    uint16_t max_y = y + scale;
    if (max_x > LCD_WIDTH) max_x = LCD_WIDTH;
    if (max_y > height) max_y = height;

    uint16_t pixel = __builtin_bswap16(color);
    for (uint16_t py = y; py < max_y; py++) {
        uint16_t *row = &row_buffer[py * LCD_WIDTH];
        for (uint16_t px = x; px < max_x; px++) {
            row[px] = pixel;
        }
    }
}

static void row_draw_char(uint16_t x, uint16_t y, char c, uint8_t scale, uint16_t height, uint16_t color)
{
    const uint8_t *rows = font_for_char(c);
    for (uint8_t row = 0; row < FONT_HEIGHT; row++) {
        for (uint8_t col = 0; col < FONT_WIDTH; col++) {
            if ((rows[row] & (1U << (4 - col))) != 0U) {
                row_draw_pixel_block(x + col * scale, y + row * scale, scale, height, color);
            }
        }
    }
}

static void row_draw_text(uint16_t x, uint16_t y, const char *text, uint8_t scale, uint16_t height, uint16_t color)
{
    uint16_t cursor_x = x;
    while (*text != '\0' && cursor_x < LCD_WIDTH) {
        row_draw_char(cursor_x, y, *text, scale, height, color);
        cursor_x += (FONT_WIDTH + FONT_SPACING) * scale;
        text++;
    }
}

static void lcd_write_row(uint16_t x, uint16_t y, uint16_t w, uint16_t h)
{
    if (!display_ready || w == 0 || h == 0) return;
    if (x >= LCD_WIDTH || y >= LCD_HEIGHT) return;
    if (x + w > LCD_WIDTH) w = LCD_WIDTH - x;
    if (y + h > LCD_HEIGHT) h = LCD_HEIGHT - y;

    lcd_set_window(x, y, x + w - 1, y + h - 1);
    lcd_write_data(row_buffer, w * h * sizeof(uint16_t));
}

static void draw_text_row(uint16_t y, const char *text, uint16_t color, uint16_t bg)
{
    row_clear(ROW_BUFFER_HEIGHT, bg);
    row_draw_text(8, 3, text, TEXT_SCALE, ROW_BUFFER_HEIGHT, color);
    lcd_write_row(0, y, LCD_WIDTH, ROW_BUFFER_HEIGHT);
}

static void display_task(void *ctx)
{
    (void)ctx;
    char line[64];
    char ap_ip[16];
    char sta_ip[16];
    char last_rx[16];
    char now_text[16];

    lcd_fill_screen(COLOR_BG);

    while (true) {
        wifi_ap_status_t ap = {0};
        wifi_sta_status_t sta = {0};
        stream_stats_values_t uart = {0};
        stream_stats_values_t caster = {0};

        wifi_ap_status(&ap);
        wifi_sta_status(&sta);

        stream_stats_handle_t uart_stats = stream_stats_get("uart");
        stream_stats_handle_t caster_stats = stream_stats_get("ntrip_caster");
        if (uart_stats != NULL) stream_stats_values(uart_stats, &uart);
        if (caster_stats != NULL) stream_stats_values(caster_stats, &caster);

        uint32_t now_ms = (uint32_t) (esp_timer_get_time() / 1000ULL);
        ip_to_text(ap_ip, sizeof(ap_ip), ap.ip4_addr, ap.active);
        ip_to_text(sta_ip, sizeof(sta_ip), sta.ip4_addr, sta.connected);
        age_to_text(last_rx, sizeof(last_rx), now_ms, uart.last_in_ms);
        time_to_text(now_text, sizeof(now_text));

        draw_text_row(6, "M5CORE RTK BASE", COLOR_TITLE, COLOR_BG);

        snprintf(line, sizeof(line), "AP  %s", ap_ip);
        draw_text_row(32, line, COLOR_TEXT, COLOR_BG);

        snprintf(line, sizeof(line), "STA %s", sta_ip);
        draw_text_row(54, line, sta.connected ? COLOR_TEXT : COLOR_WARN, COLOR_BG);

        snprintf(line, sizeof(line), "UART IN %lu B", (unsigned long) uart.total_in);
        draw_text_row(84, line, COLOR_ACCENT, COLOR_BG);

        snprintf(line, sizeof(line), "UART RATE %lu B/S", (unsigned long) uart.rate_in);
        draw_text_row(106, line, COLOR_ACCENT, COLOR_BG);

        snprintf(line, sizeof(line), "NTRIP CLIENTS %lu", (unsigned long) ntrip_caster_client_count());
        draw_text_row(136, line, COLOR_WARN, COLOR_BG);

        snprintf(line, sizeof(line), "CASTER OUT %lu B", (unsigned long) caster.total_out);
        draw_text_row(158, line, COLOR_WARN, COLOR_BG);

        snprintf(line, sizeof(line), "LAST RX %s", last_rx);
        draw_text_row(190, line, COLOR_TEXT, COLOR_BG);

        snprintf(line, sizeof(line), "UPDATE %s", now_text);
        draw_text_row(212, line, COLOR_MUTED, COLOR_BG);

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

static void ip_to_text(char *buffer, size_t buffer_size, esp_ip4_addr_t addr, bool valid)
{
    if (!valid || addr.addr == 0) {
        snprintf(buffer, buffer_size, "--");
        return;
    }

    snprintf(buffer, buffer_size, IPSTR, IP2STR(&addr));
}

static void age_to_text(char *buffer, size_t buffer_size, uint32_t now_ms, uint32_t event_ms)
{
    if (event_ms == 0) {
        snprintf(buffer, buffer_size, "--");
        return;
    }

    uint32_t age_s = (now_ms - event_ms) / 1000U;
    snprintf(buffer, buffer_size, "%lu S", (unsigned long) age_s);
}

static void time_to_text(char *buffer, size_t buffer_size)
{
    time_t now = time(NULL);
    struct tm tm_now;

    if (now > 1600000000 && localtime_r(&now, &tm_now) != NULL) {
        snprintf(buffer, buffer_size, "%02d:%02d:%02d", tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
    } else {
        uint32_t uptime_s = (uint32_t) (esp_timer_get_time() / 1000000ULL);
        snprintf(buffer, buffer_size, "%02lu:%02lu:%02lu",
                 (unsigned long) (uptime_s / 3600U),
                 (unsigned long) ((uptime_s / 60U) % 60U),
                 (unsigned long) (uptime_s % 60U));
    }
}


static const uint8_t *font_for_char(char ch)
{
    static const uint8_t space[7] = {0,0,0,0,0,0,0};
    static const uint8_t unknown[7] = {14,17,1,2,4,0,4};
    static const uint8_t dash[7] = {0,0,0,31,0,0,0};
    static const uint8_t dot[7] = {0,0,0,0,0,12,12};
    static const uint8_t colon[7] = {0,12,12,0,12,12,0};
    static const uint8_t slash[7] = {1,2,2,4,8,8,16};
    static const uint8_t zero[7] = {14,17,19,21,25,17,14};
    static const uint8_t one[7] = {4,12,4,4,4,4,14};
    static const uint8_t two[7] = {14,17,1,2,4,8,31};
    static const uint8_t three[7] = {30,1,1,14,1,1,30};
    static const uint8_t four[7] = {2,6,10,18,31,2,2};
    static const uint8_t five[7] = {31,16,30,1,1,17,14};
    static const uint8_t six[7] = {6,8,16,30,17,17,14};
    static const uint8_t seven[7] = {31,1,2,4,8,8,8};
    static const uint8_t eight[7] = {14,17,17,14,17,17,14};
    static const uint8_t nine[7] = {14,17,17,15,1,2,12};
    static const uint8_t a[7] = {14,17,17,31,17,17,17};
    static const uint8_t b[7] = {30,17,17,30,17,17,30};
    static const uint8_t glyph_c[7] = {14,17,16,16,16,17,14};
    static const uint8_t d[7] = {30,17,17,17,17,17,30};
    static const uint8_t e[7] = {31,16,16,30,16,16,31};
    static const uint8_t f[7] = {31,16,16,30,16,16,16};
    static const uint8_t g[7] = {14,17,16,23,17,17,15};
    static const uint8_t h[7] = {17,17,17,31,17,17,17};
    static const uint8_t i[7] = {14,4,4,4,4,4,14};
    static const uint8_t j[7] = {7,2,2,2,2,18,12};
    static const uint8_t k[7] = {17,18,20,24,20,18,17};
    static const uint8_t l[7] = {16,16,16,16,16,16,31};
    static const uint8_t m[7] = {17,27,21,21,17,17,17};
    static const uint8_t n[7] = {17,25,21,19,17,17,17};
    static const uint8_t o[7] = {14,17,17,17,17,17,14};
    static const uint8_t p[7] = {30,17,17,30,16,16,16};
    static const uint8_t q[7] = {14,17,17,17,21,18,13};
    static const uint8_t r[7] = {30,17,17,30,20,18,17};
    static const uint8_t s[7] = {15,16,16,14,1,1,30};
    static const uint8_t t[7] = {31,4,4,4,4,4,4};
    static const uint8_t u[7] = {17,17,17,17,17,17,14};
    static const uint8_t v[7] = {17,17,17,17,17,10,4};
    static const uint8_t w[7] = {17,17,17,21,21,21,10};
    static const uint8_t x[7] = {17,17,10,4,10,17,17};
    static const uint8_t y[7] = {17,17,10,4,4,4,4};
    static const uint8_t z[7] = {31,1,2,4,8,16,31};

    if (ch >= 'a' && ch <= 'z') ch = (char) (ch - 32);

    switch (ch) {
        case ' ': return space;
        case '-': return dash;
        case '_': return dash;
        case '.': return dot;
        case ':': return colon;
        case '/': return slash;
        case '0': return zero;
        case '1': return one;
        case '2': return two;
        case '3': return three;
        case '4': return four;
        case '5': return five;
        case '6': return six;
        case '7': return seven;
        case '8': return eight;
        case '9': return nine;
        case 'A': return a;
        case 'B': return b;
        case 'C': return glyph_c;
        case 'D': return d;
        case 'E': return e;
        case 'F': return f;
        case 'G': return g;
        case 'H': return h;
        case 'I': return i;
        case 'J': return j;
        case 'K': return k;
        case 'L': return l;
        case 'M': return m;
        case 'N': return n;
        case 'O': return o;
        case 'P': return p;
        case 'Q': return q;
        case 'R': return r;
        case 'S': return s;
        case 'T': return t;
        case 'U': return u;
        case 'V': return v;
        case 'W': return w;
        case 'X': return x;
        case 'Y': return y;
        case 'Z': return z;
        default: return unknown;
    }
}
