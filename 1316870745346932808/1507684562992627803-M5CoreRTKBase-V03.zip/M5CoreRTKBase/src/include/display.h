#ifndef M5CORE_RTK_BASE_DISPLAY_H
#define M5CORE_RTK_BASE_DISPLAY_H

void display_init();

#endif // M5CORE_RTK_BASE_DISPLAY_H
