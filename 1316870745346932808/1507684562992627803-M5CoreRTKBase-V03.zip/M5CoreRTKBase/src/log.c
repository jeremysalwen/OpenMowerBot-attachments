/*
 * This file is part of the ESP32-XBee distribution (https://github.com/nebkat/esp32-xbee).
 * Copyright (c) 2019 Nebojsa Cvetkovic.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <esp_log.h>
#include <esp_err.h>
#include <freertos/FreeRTOS.h>
#include <freertos/ringbuf.h>
#include <stdio.h>
#include <string.h>
#include <uart.h>
#include "log.h"

#define INITIAL_MAGIC "@@@@\n"

static const char *TAG = "LOG";

static RingbufHandle_t ringbuf_handle;

esp_err_t log_init() {
    ringbuf_handle = xRingbufferCreate(4096, RINGBUF_TYPE_BYTEBUF);
    if (ringbuf_handle == NULL) {
        ESP_LOGE(TAG, "Could not create log ring buffer");
        return ESP_FAIL;
    }

    // Magic string to let web log know that ESP32 has restarted (to reset line counter).
    xRingbufferSend(ringbuf_handle, INITIAL_MAGIC, strlen(INITIAL_MAGIC), 0);

    return ESP_OK;
}

int log_vprintf(const char *format, va_list arg) {
    char buffer[512];

    // Keep normal USB serial monitor logging alive. The original ESP32-XBee logger
    // only stored logs for the web UI / UART forwarding, which made PlatformIO
    // monitor look like app_main() had stopped.
    va_list console_args;
    va_copy(console_args, arg);
    int console_len = vprintf(format, console_args);
    va_end(console_args);
    fflush(stdout);

    va_list buffer_args;
    va_copy(buffer_args, arg);
    int n = vsnprintf(buffer, sizeof(buffer), format, buffer_args);
    va_end(buffer_args);

    if (n < 0) {
        return console_len;
    }

    size_t len = (n < (int) sizeof(buffer)) ? (size_t) n : sizeof(buffer) - 1U;

    if (ringbuf_handle != NULL) {
        xRingbufferSend(ringbuf_handle, buffer, len, 0);
        xRingbufferSend(ringbuf_handle, "\n", 1, 0);
    }

    uart_log(buffer, len);

    return console_len;
}

void *log_receive(size_t *length, TickType_t ticksToWait) {
    return xRingbufferReceive(ringbuf_handle, length, ticksToWait);
}

void log_return(void *item) {
    vRingbufferReturnItem(ringbuf_handle, item);
}
