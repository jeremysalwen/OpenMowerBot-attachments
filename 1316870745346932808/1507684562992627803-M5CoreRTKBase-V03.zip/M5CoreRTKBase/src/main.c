/*
 * This file is part of the ESP32-XBee distribution (https://github.com/nebkat/esp32-xbee).
 * Copyright (c) 2019 Nebojsa Cvetkovic.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <web_server.h>
#include <log.h>
#include <status_led.h>
#include <interface/socket_client.h>
#include <esp_sntp.h>
#include <core_dump.h>
#include <esp_app_desc.h>
#include <stream_stats.h>
#include <display.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_system.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_sleep.h"
#include "esp_wifi.h"

#include "driver/uart.h"
#include "driver/ledc.h"
#include "driver/gpio.h"
#include "driver/i2c.h"

#include "config.h"
#include "wifi.h"
#include "interface/socket_server.h"
#include "uart.h"
#include "interface/ntrip.h"
#include "tasks.h"

static const char *TAG = "MAIN";

#define IP5306_I2C_PORT             I2C_NUM_0
#define IP5306_I2C_SDA_GPIO         GPIO_NUM_21
#define IP5306_I2C_SCL_GPIO         GPIO_NUM_22
#define IP5306_I2C_FREQ_HZ          100000

#define IP5306_ADDR                 0x75
#define IP5306_REG_SYS_CTL0         0x00
#define IP5306_REG_SYS_CTL1         0x01
#define IP5306_REG_SYS_CTL2         0x02

#define IP5306_BOOST_ENABLE_BIT     0x20
#define IP5306_BOOST_OUT_BIT        0x02
#define IP5306_BOOST_BUTTON_EN_BIT  0x01
#define IP5306_SHUTDOWNTIME_MASK    0x0C
#define IP5306_SHUTDOWNTIME_8S      0x00

static char *reset_reason_name(esp_reset_reason_t reason);

static esp_err_t ip5306_i2c_init();
static esp_err_t ip5306_read_reg(uint8_t reg, uint8_t *value);
static esp_err_t ip5306_write_reg(uint8_t reg, uint8_t value);
static esp_err_t ip5306_update_reg(uint8_t reg, uint8_t mask, uint8_t value);
static void ip5306_power_off();

static void reset_button_task() {
    gpio_config_t io_conf = {
            .pin_bit_mask = 1ULL << GPIO_NUM_39,
            .mode = GPIO_MODE_INPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE
    };

    gpio_config(&io_conf);

    uint32_t held_ms = 0;

    while (true) {
        if (gpio_get_level(GPIO_NUM_39) == 0) {
            held_ms += 100;

            if (held_ms >= 5000) {
                ESP_LOGI(TAG, "Power button held: requesting IP5306 power off");

                // while (gpio_get_level(GPIO_NUM_39) == 0) {
                //     vTaskDelay(pdMS_TO_TICKS(100));
                // }

                ip5306_power_off();
            }
        } else {
            held_ms = 0;
        }

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

static void sntp_time_set_handler(struct timeval *tv) {
    ESP_LOGI(TAG, "Synced time from SNTP");
}

void app_main()
{
    status_led_init();
    status_led_handle_t status_led = status_led_add(0xFFFFFF33, STATUS_LED_FADE, 250, 2500, 0);

    log_init();
    esp_log_set_vprintf(log_vprintf);
    esp_log_level_set("gpio", ESP_LOG_WARN);
    esp_log_level_set("system_api", ESP_LOG_WARN);
    esp_log_level_set("wifi", ESP_LOG_WARN);
    esp_log_level_set("esp_netif_handlers", ESP_LOG_WARN);

    core_dump_check();

    ip5306_i2c_init();

    xTaskCreate(reset_button_task, "reset_button", 4096, NULL, TASK_PRIORITY_RESET_BUTTON, NULL);

    stream_stats_init();
    display_init();

    config_init();
    uart_init();

    esp_reset_reason_t reset_reason = esp_reset_reason();

    const esp_app_desc_t *app_desc = esp_app_get_description();
    char elf_buffer[17];
    esp_app_get_elf_sha256(elf_buffer, sizeof(elf_buffer));

    uart_nmea("$PESP,INIT,START,%s,%s", app_desc->version, reset_reason_name(reset_reason));

    ESP_LOGI(TAG, "╔══════════════════════════════════════════════╗");
    ESP_LOGI(TAG, "║ ESP32 XBee %-33s "                          "║", app_desc->version);
    ESP_LOGI(TAG, "╠══════════════════════════════════════════════╣");
    ESP_LOGI(TAG, "║ Compiled: %8s %-25s "                       "║", app_desc->time, app_desc->date);
    ESP_LOGI(TAG, "║ ELF SHA256: %-32s "                         "║", elf_buffer);
    ESP_LOGI(TAG, "║ ESP-IDF: %-35s "                            "║", app_desc->idf_ver);
    ESP_LOGI(TAG, "╟──────────────────────────────────────────────╢");
    ESP_LOGI(TAG, "║ Reset reason: %-30s "                       "║", reset_reason_name(reset_reason));
    ESP_LOGI(TAG, "╟──────────────────────────────────────────────╢");
    ESP_LOGI(TAG, "║ Author: Nebojša Cvetković                    ║");
    ESP_LOGI(TAG, "║ Source: https://github.com/nebkat/esp32-xbee ║");
    ESP_LOGI(TAG, "╚══════════════════════════════════════════════╝");

    esp_event_loop_create_default();

    vTaskDelay(pdMS_TO_TICKS(2500));
    status_led->interval = 100;
    status_led->duration = 1000;
    status_led->flashing_mode = STATUS_LED_BLINK;

    if (reset_reason != ESP_RST_POWERON && reset_reason != ESP_RST_SW && reset_reason != ESP_RST_WDT) {
        status_led->active = false;
        status_led_handle_t error_led = status_led_add(0xFF000033, STATUS_LED_BLINK, 50, 10000, 0);

        vTaskDelay(pdMS_TO_TICKS(10000));

        status_led_remove(error_led);
        status_led->active = true;
    }

    net_init();
    wifi_init();

    web_server_init();

    ntrip_caster_init();
    ntrip_server_init();
    ntrip_client_init();

    socket_server_init();
    socket_client_init();

    uart_nmea("$PESP,INIT,COMPLETE");

    wait_for_ip();

    esp_sntp_setoperatingmode(SNTP_OPMODE_POLL);
    esp_sntp_setservername(0, "pool.ntp.org");
    sntp_set_sync_mode(SNTP_SYNC_MODE_SMOOTH);
    sntp_set_time_sync_notification_cb(sntp_time_set_handler);
    esp_sntp_init();

#ifdef DEBUG_HEAP
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(2000));

        multi_heap_info_t info;
        heap_caps_get_info(&info, MALLOC_CAP_DEFAULT);

        uart_nmea("$PESP,HEAP,FREE,%d/%d,%d%%", info.total_free_bytes,
                info.total_allocated_bytes + info.total_free_bytes,
                100 * info.total_free_bytes / (info.total_allocated_bytes + info.total_free_bytes));
    }
#endif
}

static esp_err_t ip5306_i2c_init() {
    i2c_config_t conf = {
            .mode = I2C_MODE_MASTER,
            .sda_io_num = IP5306_I2C_SDA_GPIO,
            .scl_io_num = IP5306_I2C_SCL_GPIO,
            .sda_pullup_en = GPIO_PULLUP_ENABLE,
            .scl_pullup_en = GPIO_PULLUP_ENABLE,
            .master.clk_speed = IP5306_I2C_FREQ_HZ
    };

    esp_err_t err = i2c_param_config(IP5306_I2C_PORT, &conf);
    if (err != ESP_OK) {
        return err;
    }

    err = i2c_driver_install(IP5306_I2C_PORT, I2C_MODE_MASTER, 0, 0, 0);
    if (err == ESP_ERR_INVALID_STATE) {
        return ESP_OK;
    }

    return err;
}

static esp_err_t ip5306_read_reg(uint8_t reg, uint8_t *value) {
    return i2c_master_write_read_device(
            IP5306_I2C_PORT,
            IP5306_ADDR,
            &reg,
            1,
            value,
            1,
            pdMS_TO_TICKS(100));
}

static esp_err_t ip5306_write_reg(uint8_t reg, uint8_t value) {
    uint8_t data[2] = { reg, value };

    return i2c_master_write_to_device(
            IP5306_I2C_PORT,
            IP5306_ADDR,
            data,
            sizeof(data),
            pdMS_TO_TICKS(100));
}

static esp_err_t ip5306_update_reg(uint8_t reg, uint8_t mask, uint8_t value) {
    uint8_t current = 0;

    esp_err_t err = ip5306_read_reg(reg, &current);
    if (err != ESP_OK) {
        return err;
    }

    current = (current & ~mask) | (value & mask);

    return ip5306_write_reg(reg, current);
}

static void ip5306_power_off() {
    esp_err_t err = ip5306_i2c_init();

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "IP5306 I2C init failed: %s", esp_err_to_name(err));
    } else {
        ESP_LOGI(TAG, "Disabling IP5306 boost keep-on");

        ip5306_update_reg(IP5306_REG_SYS_CTL1,
                          IP5306_BOOST_ENABLE_BIT,
                          0);

        ip5306_update_reg(IP5306_REG_SYS_CTL0,
                          IP5306_BOOST_OUT_BIT,
                          0);

        ip5306_update_reg(IP5306_REG_SYS_CTL2,
                          IP5306_SHUTDOWNTIME_MASK,
                          IP5306_SHUTDOWNTIME_8S);

        ip5306_update_reg(IP5306_REG_SYS_CTL0,
                          IP5306_BOOST_BUTTON_EN_BIT,
                          IP5306_BOOST_BUTTON_EN_BIT);
    }

    esp_wifi_disconnect();
    esp_wifi_stop();

    ESP_LOGI(TAG, "Entering deep sleep while waiting for IP5306 shutdown");

    vTaskDelay(pdMS_TO_TICKS(200));

    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
    esp_deep_sleep_start();
}

static char *reset_reason_name(esp_reset_reason_t reason) {
    switch (reason) {
        default:
        case ESP_RST_UNKNOWN:
            return "UNKNOWN";
        case ESP_RST_POWERON:
            return "POWERON";
        case ESP_RST_EXT:
            return "EXTERNAL";
        case ESP_RST_SW:
            return "SOFTWARE";
        case ESP_RST_PANIC:
            return "PANIC";
        case ESP_RST_INT_WDT:
            return "INTERRUPT_WATCHDOG";
        case ESP_RST_TASK_WDT:
            return "TASK_WATCHDOG";
        case ESP_RST_WDT:
            return "OTHER_WATCHDOG";
        case ESP_RST_DEEPSLEEP:
            return "DEEPSLEEP";
        case ESP_RST_BROWNOUT:
            return "BROWNOUT";
        case ESP_RST_SDIO:
            return "SDIO";
    }
}