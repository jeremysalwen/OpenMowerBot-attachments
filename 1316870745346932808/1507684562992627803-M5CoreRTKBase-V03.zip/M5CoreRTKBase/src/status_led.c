#include "status_led.h"
#include <stdbool.h>
#include <stdlib.h>

void status_led_init()
{
}

void status_led_clear()
{
}

status_led_handle_t status_led_add(
        uint32_t rgba,
        status_led_flashing_mode_t flashing_mode,
        uint32_t interval,
        uint32_t duration,
        uint8_t expire)
{
    status_led_handle_t color = calloc(1, sizeof(struct status_led_color_t));

    if (color != NULL)
    {
        color->red = (rgba >> 24u) & 0xFFu;
        color->green = (rgba >> 16u) & 0xFFu;
        color->blue = (rgba >> 8u) & 0xFFu;
        color->flashing_mode = flashing_mode;
        color->interval = interval;
        color->duration = duration;
        color->expire = expire;
        color->active = true;
    }

    return color;
}

void status_led_remove(status_led_handle_t color)
{
    free(color);
}

void rssi_led_set(uint8_t value)
{
    (void)value;
}

void rssi_led_fade(uint8_t value, int max_fade_time_ms)
{
    (void)value;
    (void)max_fade_time_ms;
}

void assoc_led_set(uint8_t value)
{
    (void)value;
}

void assoc_led_fade(uint8_t value, int max_fade_time_ms)
{
    (void)value;
    (void)max_fade_time_ms;
}

void sleep_led_set(uint8_t value)
{
    (void)value;
}

void sleep_led_fade(uint8_t value, int max_fade_time_ms)
{
    (void)value;
    (void)max_fade_time_ms;
}
