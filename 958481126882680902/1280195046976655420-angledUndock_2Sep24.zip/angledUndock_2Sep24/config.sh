# Add the following to the Mower Logic Settings section of mower_config.txt and adjust values to suit your needs

# The distance from the dock point to the start of the approach path
export OM_DOCKING_APPROACH_DISTANCE=1.5

# The distance to drive forward AFTER reaching the second docking point
export OM_DOCKING_DISTANCE=0.5

# The first stage distance to drive for undocking. As a minimum it needs to clear the dock.  
# If the additional angled move isn't used then this needs to be large enough for the robot to have GPS reception 
export OM_UNDOCK_DISTANCE=1.0

# The additional second stage distance to drive at an angle for undocking. This needs to be large enough for the robot to have GPS reception
# Note - this section may still be driven without gps so don't expect high positional accuracy.
export OM_UNDOCK_ANGLED_DISTANCE=0.5

# The angle at which to drive for the additional distance (neg values are to the left of the dock, pos to the right).
export OM_UNDOCK_ANGLE=-90.0

# If true will allways use the angle specified.
# If false will vary the undocking angle between +abs(OM_UNDOCK_ANGLE) to -abs(OM_UNDOCK_ANGLE) on subsequent undocks to reduce grass wear
export OM_UNDOCK_FIXED_ANGLE=False

# If true will use a vurved second stage undock move, if false will use a straight undock move.
export OM_UNDOCK_USE_CURVE=False
