# Add the following to the <node pkg="mower_logic" type="mower_logic" name="mower_logic" output="screen"> section
# of open_mower.launch and sim_mower_logic.launch to make the new parameters available from the command line/mower_config

        <param name="docking_approach_distance" value="$(env OM_DOCKING_APPROACH_DISTANCE)"/>
        <param name="undock_angled_distance" value="$(optenv OM_UNDOCK_ANGLED_DISTANCE 0.0)"/>
        <param name="undock_angle" value="$(optenv OM_UNDOCK_ANGLE 0.0)"/>
        <param name="undock_fixed_angle" value="$(optenv OM_UNDOCK_FIXED_ANGLE True)"/>
        <param name="undock_use_curve" value="$(optenv OM_UNDOCK_USE_CURVE True)"/>
