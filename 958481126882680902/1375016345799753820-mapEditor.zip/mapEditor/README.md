# How to run MapEditor

- Open mapEditor folder in VS Code
- Run `./vscode/launch.json` file
- Select `map.bag` file to be edited
- Edit the map
- Edited map will be saved in `/output` dir
