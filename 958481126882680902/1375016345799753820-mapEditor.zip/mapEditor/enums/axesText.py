from enum import Enum

class AxesText(Enum):
    PLOT_TITLE = 'Click, drag or use shortcut keys'
    DEFAULT = 'd delete point or area\ni insert point or area\nh hide area\nm merge mowing areas\nc convert area to restricted area\ns split area\nt set starting point for mowing area\n[digit]+click mowing area to set mowing order\n'
    POINT_SELECTED = 'd delete point or area\ni insert point or area\nh hide area\nm merge mowing areas\nc convert area to restricted area\ns split area\n[digit]+click mowing area to set mowing order\n\u2190 \u2192 \u2191 \u2193 move the point to the left right top bottom by 10cm (shift+ \u2190 \u2192 \u2191 \u2193 by 1cm)\n'
