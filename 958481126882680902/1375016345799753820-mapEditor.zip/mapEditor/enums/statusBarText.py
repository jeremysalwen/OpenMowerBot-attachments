from enum import Enum

class StatusBarText(Enum):
    FIRST = 1
    SECOND = 2
    THIRD = 3
    FOURTH = 4
    FIFTH = 5
    SIXTH = 6
    SEVENTH = 7
    EIGHTH = 8
    NINTH = 9
    MOWING_AREA_ORDER = 'Mowing Area set as '
    MOWING_AREA_TO_MOW = ' to mow'
    SELECT_AREA_TO_MERGE = 'Select Area to merge'
    SELECT_POINT_TO_MERGE = 'Select Point of Area to merge with (Right click - reversed)'
    AREAS_MERGED = 'Areas merged'
    SELECT_AREA_TO_CONVERT = 'Select Area to convert to Restricted Area'
    SELECT_AREA_TO_ADD_RESTRICIONS = 'Select Area to add Restricted Area to'
    AREA_CONVERTED = 'Area converted'
    SELECT_FIRST_SPLIT_POINT = 'Select first split point'
    SELECT_SECOND_SPLIT_POINT = 'Select second split point'
    AREA_SPLIT = 'Area split'
    SELECT_STARTING_POINT = 'Select starting Point for Mowing Area'
    STARTING_POINT_SELECTED = 'Starting Point selected'