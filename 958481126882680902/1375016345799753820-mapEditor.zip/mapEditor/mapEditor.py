import pathlib
import rosbag
import matplotlib.pyplot as plt
from tkinter import filedialog as fd

from models.map import Map


def editMap():
        bagfile = fd.askopenfile(filetypes=[('map bag files', '*.bag')])

        if bagfile == None:
            return

        bag = rosbag.Bag(bagfile.name)

        pathlib.Path('/output').mkdir(parents=True, exist_ok=True)
        
        with rosbag.Bag('output/map.bag', 'w') as outbag:
            plt.rcParams['toolbar'] = 'toolmanager'
            plt.rcParams["figure.autolayout"] = True
            
            map = Map()

            for topic, msg, t in bag.read_messages():
                match topic:
                    case 'docking_point':
                        map.addDockingPoint(msg)
                    case 'mowing_areas':
                        map.addMowingArea(msg)
                    case 'navigation_areas':
                        map.addNavigationArea(msg)

            plt.show()
            #figure closed by user, get the new data

            if map.dockingPoint != None:
                outbag.write('docking_point', map.dockingPoint.msg)

            for mowingArea in map.mowingAreas:
                outbag.write('mowing_areas', mowingArea.msg)

            for navigationArea in map.navigationAreas:
                outbag.write('navigation_areas', navigationArea.msg)


if __name__ == '__main__':
    editMap()