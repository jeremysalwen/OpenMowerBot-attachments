from matplotlib.axes import Axes
from geometry_msgs.msg import Polygon
from geometry_msgs.msg import Point32

from geometryMsgs.mapArea import MapArea

from models.geometry import Geometry
from models.obstacle import Obstacle

class Area(Geometry):
    def __init__(self, ax: Axes, area: Polygon, obstacles: list[Polygon]):

        super().__init__(ax, area.points)
        self.obstacles = list[Obstacle]()

        for obstacle in obstacles:
            self.obstacles.append(Obstacle(ax, obstacle.points, self))

    @property
    def msg(self):
        mapArea = MapArea()
        area = Polygon()
        for x,y in self.poly.xy:
            area.points.append(Point32(x,y,0))

        mapArea.area = area

        for obstacle in self.obstacles:
            obst = Polygon()
            for x,y in obstacle.poly.xy:
                obst.points.append(Point32(x,y,0))

            mapArea.obstacles.append(obst)
        
        return mapArea
        