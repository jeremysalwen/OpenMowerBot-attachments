
from matplotlib.axes import Axes
from geometry_msgs.msg import Point32
from geometry_msgs.msg import Quaternion
from geometry_msgs.msg import Pose

from models.geometry import Geometry

class DockingPoint(Geometry):
    def __init__(self, ax: Axes, position: Point32, orientation: Quaternion):

        super().__init__(ax, [position])
        self.type = 'Docking Point'
        self.orientation = orientation
        self.poly.set_facecolor('deepskyblue')
        self.line.set_markerfacecolor('blue')

    @property
    def msg(self):
        pose = Pose()
        pose.position = Point32(self.poly.xy[0][0], self.poly.xy[0][1], 0)
        pose.orientation = self.orientation

        return pose