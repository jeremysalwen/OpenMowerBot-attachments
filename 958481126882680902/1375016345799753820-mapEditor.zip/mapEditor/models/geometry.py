import uuid
import numpy as np
from geometry_msgs.msg import Point32
from matplotlib.patches import Polygon as Poly
from matplotlib.lines import Line2D
from matplotlib.axes import Axes

class Geometry:
    def __init__(self, ax: Axes, points: list[Point32]):
    
        self.uuid = uuid.uuid4()
        self.poly = self.getPolygon(points)
        self.ax = ax
        self.ax.add_patch(self.poly)
        self.line = self.getLine(self.poly.xy)         
        self.ax.add_line(self.line)
        self.canvas = self.ax.figure.canvas
        self.canvas.zorder += 1
        self.selectedPointIndex = None
        self.poly.zorder = self.canvas.zorder
     
        self.setAxesLimits(self.poly.xy)

        # self.canvas.background = self.canvas.copy_from_bbox(self.ax.bbox)
        self.on_draw_cid = self.canvas.mpl_connect('draw_event', self.on_draw)
        self.redraw()

    def getPolygon(self, points):
        x_list = []
        y_list = []
        for point in points:
            x_list.append(point.x)
            y_list.append(point.y)

        return Poly(np.column_stack([x_list, y_list]), animated=True)

    def getLine(self, points):

        x, y = zip(*points)
        return Line2D(x, y, marker='o', markersize=6, animated=True)

    def setAxesLimits(self, points):
        x, y = zip(*points)
        x = list(x)
        y = list(y)
        xlim = self.ax.get_xlim()
        ylim = self.ax.get_ylim()
        if xlim[0] != 0:
            x.append(xlim[0])
            x.append(xlim[1])

        self.ax.set_xlim(min(x) - 1, max(x) + 1)

        if ylim[0] != 0:
            y.append(ylim[0])
            y.append(ylim[1])

        self.ax.set_ylim(min(y) - 1, max(y) + 1)

    def selectPoint(self, pointIndex):
        self.selectedPointIndex = pointIndex
        self.line.set_markersize(10)
        self.line.set_markevery(slice(pointIndex, pointIndex + 1, 1))
        self.redraw()

    def deselectPoint(self):
        if self.selectedPointIndex == None:
            return
        self.selectedPointIndex = None
        self.line.set_markersize(6)
        self.line.set_markevery(None)
        self.redraw()

    def movePoint(self, pointIndex, key, x = None, y = None):
        match key:
            case 'left':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0] - 0.1, self.poly.xy[pointIndex][1]
            case 'shift+left':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0] - 0.01, self.poly.xy[pointIndex][1]
            case 'right':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0] + 0.1, self.poly.xy[pointIndex][1]
            case 'shift+right':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0] + 0.01, self.poly.xy[pointIndex][1]
            case 'up':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0], self.poly.xy[pointIndex][1] + 0.1
            case 'shift+up':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0], self.poly.xy[pointIndex][1] + 0.01
            case 'down':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0], self.poly.xy[pointIndex][1] - 0.1
            case 'shift+down':
                self.poly.xy[pointIndex] = self.poly.xy[pointIndex][0], self.poly.xy[pointIndex][1] - 0.01
            case 'mouse+move':
                self.poly.xy[pointIndex] = x, y
                if pointIndex == 0:
                    self.poly.xy[-1] = x, y
                elif pointIndex == len(self.poly.xy) - 1:
                    self.poly.xy[0] = x, y
        
        self.line.set_data(zip(*self.poly.xy))
        self.redraw()

    def addPoints(self, points):
        self.poly.xy = points
        self.line.set_data(zip(*self.poly.xy))
        self.redraw()

    def addPoint(self, index):
        self.poly.xy = np.insert(self.poly.xy, index+1, self.poly.xy[index], axis=0)
        self.line.set_data(zip(*self.poly.xy))
        self.redraw()

    def deletePoint(self, pointIndex):
        if len(self.poly.xy) < 3:
            return
        
        self.deselectPoint()
        self.poly.xy = np.delete(self.poly.xy, pointIndex, axis=0)
        self.line.set_data(zip(*self.poly.xy))
        self.redraw()

    def delete(self):
        self.poly.remove()
        self.poly = None
        self.line.remove()
        self.line = None
        self.redraw()
        self.canvas.mpl_disconnect(self.on_draw_cid)

    def hide(self):
        self.poly.set_visible(False)
        self.line.set_visible(False)
        self.redraw()

    def on_draw(self, event):
        if self.poly != None:
            self.ax.draw_artist(self.poly)
        if self.line != None:
            self.ax.draw_artist(self.line)
        # do not need to blit here, this will fire before the screen is
        # updated

    def redraw(self):
        self.canvas.draw()
        return

        # self.canvas.background = self.canvas.copy_from_bbox(self.ax.bbox)
        # self.canvas.restore_region(self.canvas.background)
        # self.ax.draw_artist(self.poly)
        # self.ax.draw_artist(self.line)
        # self.canvas.blit(self.ax.bbox)

