import numpy as np
import ctypes

from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point32
from geometry_msgs.msg import Polygon
from geometryMsgs.mapArea import MapArea

from models.mapStatus import MapStatus
from enums.status import Status
from enums.statusBarText import StatusBarText
from enums.messageBoxStyle import MessageBoxStyle
from enums.axesText import AxesText
from models.plot import Plot
from models.dockingPoint import DockingPoint
from models.geometry import Geometry
from models.mowingArea import MowingArea
from models.navigationArea import NavigationArea
from models.obstacle import Obstacle

class Map:
    def __init__(self):
        self.plot = Plot()
        self._selectedGeometry = None
        self._selectedPointIndex = None
        self._isMovingThePoint = False
        self._mapStatus = MapStatus()
        self.on_button_press_cid = self.plot.canvas.mpl_connect('button_press_event', self.on_button_press)
        self.on_key_press_cid = self.plot.canvas.mpl_connect('key_press_event', self.on_key_press)
        self.on_mouse_move_cid = self.plot.canvas.mpl_connect('motion_notify_event', self.on_mouse_move)

        self.dockingPoint = DockingPoint
        self.mowingAreas = list[MowingArea]()
        self.navigationAreas = list[NavigationArea]()

    def addDockingPoint(self, msg: Pose):
        self.dockingPoint = DockingPoint(self.plot.axes, msg.position, msg.orientation)

    def addMowingArea(self, msg: MapArea):
        self.mowingAreas.append(MowingArea(self.plot.axes, msg.area, msg.obstacles))

    def addNavigationArea(self, msg: MapArea):
        self.navigationAreas.append(NavigationArea(self.plot.axes, msg.area, msg.obstacles))

    def on_button_press(self, event):
        """Callback for mouse button presses."""
        if event.inaxes is None:
            return
        if event.button != 1 and event.button != 3:
            return      

        self._selectedGeometry = self._getGeometryUnderTheMouse(event)
        self._selectedPointIndex = self._getPointIndexUnderTheMouse(event, self._selectedGeometry)

        if self._mapStatus.status != Status.IDLE:
            match self._mapStatus.status:
                case Status.CONVERT_SELECTING_SOURCE_AREA:
                    if self._selectedGeometry != None and type(self._selectedGeometry) is not Obstacle:
                        self._mapStatus.geometry1 = self._selectedGeometry
                        self._mapStatus.status = Status.CONVERT_SELECTING_TARGET_AREA
                        self.plot.showStatusText(StatusBarText.SELECT_AREA_TO_ADD_RESTRICIONS.value, False)
                case Status.CONVERT_SELECTING_TARGET_AREA:
                    if self._selectedGeometry != None and type(self._selectedGeometry) is MowingArea and self._selectedGeometry != self._mapStatus.geometry1:
                        self._mapStatus.geometry2 = self._selectedGeometry
                        answer = self._messageBox('Convert to Restricted Area', 'Are you sure you want to convert ' + self._selectedGeometry.type + ' to Restricted Area?',  MessageBoxStyle.YesNo)
                        if answer != 6:
                            self._mapStatus.status = Status.IDLE
                            self.plot.hideStatusText()
                            return
                        self._convertToRestrictedArea()
                        self.plot.showStatusText(StatusBarText.AREA_CONVERTED.value)
                case Status.MERGE_SELECTING_AREA:
                    if self._selectedGeometry != None and type(self._selectedGeometry) is MowingArea:
                        self._mapStatus.geometry1 = self._selectedGeometry
                        self._mapStatus.status = Status.MERGE_SELECTING_MERGE_POINT
                        self.plot.showStatusText(StatusBarText.SELECT_POINT_TO_MERGE.value, False)
                case Status.MERGE_SELECTING_MERGE_POINT:
                    if self._selectedPointIndex != None and type(self._selectedGeometry) is MowingArea and self._selectedGeometry != self._mapStatus.geometry1:
                        self._mapStatus.geometry2 = self._selectedGeometry
                        answer = self._messageBox('Merge Areas', 'Are you sure you want to merge Mowing Areas?',  MessageBoxStyle.YesNo)
                        if answer != 6:
                            self._mapStatus.status = Status.IDLE
                            self.plot.hideStatusText()
                            return
                        self._mergeAreas(self._selectedPointIndex, event.button == 3)
                        self.plot.showStatusText(StatusBarText.AREAS_MERGED.value)
                        self._mapStatus.status = Status.IDLE
                case Status.SPLIT_SELECTING_FIRST_POINT:
                    if self._selectedGeometry != None and self._selectedPointIndex != None:
                        self._mapStatus.geometry1 = self._selectedGeometry
                        self._mapStatus.selectedPointIndex1 = self._selectedPointIndex
                        self._selectedPointIndex = None
                        self._deselectAll()
                        self._mapStatus.status = Status.SPLIT_SELECTING_SECOND_POINT
                        self.plot.showStatusText(StatusBarText.SELECT_SECOND_SPLIT_POINT.value, False)
                case Status.SPLIT_SELECTING_SECOND_POINT:
                    if self._selectedGeometry != None and self._selectedGeometry == self._mapStatus.geometry1 and self._selectedPointIndex != None and self._selectedPointIndex != self._mapStatus.selectedPointIndex1:
                        self._mapStatus.selectedPointIndex2 = self._selectedPointIndex
                        answer = self._messageBox('Split area', 'Are you sure you want to split ' + self._mapStatus.geometry1.type + '?',  MessageBoxStyle.YesNo)
                        if answer != 6:
                            self._mapStatus.status = Status.IDLE
                            self.plot.hideStatusText()
                            return
                        self._splitArea()
                        self.plot.showStatusText(StatusBarText.AREA_SPLIT.value)
                        self._mapStatus.status = Status.IDLE
                case Status.SET_STARTING_POINT:
                    if self._selectedGeometry != None and type(self._selectedGeometry) is MowingArea:
                        self._setStartingPoint()
                        self.plot.showStatusText(StatusBarText.STARTING_POINT_SELECTED.value)
                        self._mapStatus.status = Status.IDLE
            return

        if event.key != None and event.key.isdigit() and event.key != '0':
            if self._selectedGeometry != None and type(self._selectedGeometry) is MowingArea:
                self._setMowingAreaIndex(self._selectedGeometry, int(event.key))
        elif self._selectedPointIndex != None:
            self._selectedGeometry.selectPoint(self._selectedPointIndex)
            self.plot.setAxesText(AxesText.POINT_SELECTED)
        else:
            self._deselectAll()
            self.plot.setAxesText(AxesText.DEFAULT)

    def on_key_press(self, event):
        """Callback for key presses."""
        if not event.inaxes:
            return

        if event.key == 'escape':
            self._mapStatus.status = Status.IDLE
            self.plot.hideStatusText()
            return
        if event.key == 'c':
            self._mapStatus.status = Status.CONVERT_SELECTING_SOURCE_AREA
            self.plot.showStatusText(StatusBarText.SELECT_AREA_TO_CONVERT.value, False)
        elif event.key == 'd':
            geometry = self._getGeometryUnderTheMouse(event)
            selectedPointIndex = self._getPointIndexUnderTheMouse(event,geometry)

            if selectedPointIndex != None:
                geometry.deletePoint(selectedPointIndex)
            elif geometry != None:
                answer = self._messageBox('Delete ' + geometry.type, 'Are you sure you want to delete ' + geometry.type + '?',  MessageBoxStyle.YesNo)
                if answer == 6:
                    self._deleteGeometry(geometry)
        elif event.key == 'h':
            geometry = self._getGeometryUnderTheMouse(event)
            if geometry != None:
                geometry.hide()
        elif event.key == 'i':         
            geometry = self._getGeometryUnderTheMouse(event)
            selectedPointIndex = self._getPointIndexUnderTheMouse(event,geometry)

            if selectedPointIndex != None:
                geometry.addPoint(selectedPointIndex)
                if self._selectedPointIndex is None:
                    return
                self._selectedPointIndex += 1
                geometry.selectPoint(self._selectedPointIndex)
            elif geometry != None:
                if type(geometry) is DockingPoint or type(geometry) is Obstacle:
                    return
                geometry.obstacles.append(Obstacle(self.plot.axes, [Point32(event.xdata - 1, event.ydata - 1, 0), Point32(event.xdata + 1, event.ydata - 1, 0), Point32(event.xdata + 1, event.ydata + 1, 0), Point32(event.xdata - 1, event.ydata + 1, 0)], geometry))
        elif event.key == 'm':
            self._mapStatus.status = Status.MERGE_SELECTING_AREA
            self.plot.showStatusText(StatusBarText.SELECT_AREA_TO_MERGE.value, False)
        elif event.key == 's':
            self._mapStatus.status = Status.SPLIT_SELECTING_FIRST_POINT
            self.plot.showStatusText(StatusBarText.SELECT_FIRST_SPLIT_POINT.value, False)
        elif event.key == 't':
            self._mapStatus.status = Status.SET_STARTING_POINT
            self.plot.showStatusText(StatusBarText.SELECT_STARTING_POINT.value, False)
        else:
            if self._selectedPointIndex != None:
                self._selectedGeometry.movePoint(self._selectedPointIndex, event.key)
           
    def on_mouse_move(self, event):
        """Callback for mouse movements."""
        if event.inaxes is None:
            return
        
        if event.button == 1:
            if self._selectedPointIndex != None:
                self._selectedGeometry.movePoint(self._selectedPointIndex, 'mouse+move', event.xdata, event.ydata)
                self._isMovingThePoint = True
        else:
            if self._selectedPointIndex != None and self._isMovingThePoint == False:
                return
            geometry = self._getGeometryUnderTheMouse(event)
            selectedPointIndex = self._getPointIndexUnderTheMouse(event, geometry)
            if selectedPointIndex != None:
                geometry.selectPoint(selectedPointIndex)
            else:
                self._deselectAll()
                self._selectedPointIndex = None
                self._isMovingThePoint = False

    def _getGeometryUnderTheMouse(self, event):
        patch = self.plot.getPatchUnderTheMouse(event)
        if patch == None:
            return None
        for mowingArea in self.mowingAreas:
            if mowingArea.poly == patch:
                return mowingArea
            
            for obstacle in mowingArea.obstacles:
                if obstacle.poly == patch:
                    return obstacle

        for navigationArea in self.navigationAreas:
            if navigationArea.poly == patch:
                return navigationArea
            
            for obstacle in navigationArea.obstacles:
                if obstacle.poly == patch:
                    return obstacle

        return None

    def _getPointIndexUnderTheMouse(self, event, geometry: Geometry):
        """
        Return the index of the point closest to the event position or *None*
        if no point is within ``self.epsilon`` to the event position.
        """
        # display coords
        if geometry == None:
            return None
        
        xy = np.asarray(geometry.poly.xy)
        xyt = geometry.poly.get_transform().transform(xy)
        xt, yt = xyt[:, 0], xyt[:, 1]
        d = np.hypot(xt - event.x, yt - event.y)
        indseq, = np.nonzero(d == d.min())
        ind = indseq[0]

        if d[ind] >= self.plot.epsilon:
            ind = None

        return ind

    def _deselectAll(self):
        for mowingArea in self.mowingAreas:
            mowingArea.deselectPoint()
            for obstacle in mowingArea.obstacles:
                obstacle.deselectPoint()

        for navigationArea in self.navigationAreas:
            navigationArea.deselectPoint()
            for obstacle in navigationArea.obstacles:
                obstacle.deselectPoint()

    def _mergeAreas(self, mergePointIndex, reverse):
        xys1 = self._mapStatus.geometry1.poly.xy
        if reverse:
            xys1 = reversed(self._mapStatus.geometry1.poly.xy)
        xys2 = self._mapStatus.geometry2.poly.xy
        index = 0
        for xy in xys1:
            xys2 = np.insert(xys2, mergePointIndex + index, xy, axis=0)
            index += 1

        self._mapStatus.geometry2.addPoints(xys2)
        for obstacle in self._mapStatus.geometry1.obstacles:
            self._mapStatus.geometry2.obstacles.append(obstacle)
        self._deleteGeometry(self._mapStatus.geometry1)

    def _convertToRestrictedArea(self):
        points = list[Point32]()
        for xy in self._mapStatus.geometry1.poly.xy:
            points.append(Point32(xy[0], xy[1], 0))
        self._mapStatus.geometry2.obstacles.append(Obstacle(self.plot.axes, points,self._mapStatus.geometry2))
        self._deleteGeometry(self._mapStatus.geometry1)
        
    def _splitArea(self):
        xys = self._mapStatus.geometry1.poly.xy
        points1 = []
        points2 = list[Point32]()
        index = 0
        ind1 = min(self._mapStatus.selectedPointIndex1, self._mapStatus.selectedPointIndex2)
        ind2 = max(self._mapStatus.selectedPointIndex1, self._mapStatus.selectedPointIndex2)
        for xy in xys:
            if index >= ind1 and index < ind2:
                points2.append(Point32(xy[0], xy[1], 0))
            else:
                points1.append(xy)
            index += 1
        if len(points1) < 3 or len(points2) < 3:
            return
        
        self.mowingAreas.append(MowingArea(self.plot.axes, Polygon(points2), []))
        self._mapStatus.geometry1.addPoints(points1)
        msg = self._mapStatus.geometry1.msg
        self._deleteGeometry(self._mapStatus.geometry1)
        self.addMowingArea(msg)

    def _setMowingAreaIndex(self, geometry: Geometry, index: int):
        mowingAreasLen = len(self.mowingAreas) - 1
        for mowingArea in self.mowingAreas:
            if mowingArea == geometry:
                self.mowingAreas.insert(min(mowingAreasLen, index - 1), self.mowingAreas.pop(self.mowingAreas.index(mowingArea)))
                self.plot.showStatusText(StatusBarText.MOWING_AREA_ORDER.value + StatusBarText(min(mowingAreasLen + 1, index)).name + StatusBarText.MOWING_AREA_TO_MOW.value)
                break

    def _messageBox(self, title: str, text: str, style: MessageBoxStyle):
        return ctypes.windll.user32.MessageBoxW(0, text, title, style.value)
    
    def _deleteGeometry(self, geometry: Geometry):
        geometry.delete()

        if type(geometry) is MowingArea:
            self.mowingAreas.remove(geometry)
        elif type(geometry) is NavigationArea:
            self.navigationAreas.remove(geometry)

    def _setStartingPoint(self):
        xys = self._selectedGeometry.poly.xy

        self._selectedGeometry.poly.xy = np.insert(xys[0:self._selectedPointIndex], 0, xys[self._selectedPointIndex:len(xys)], axis=0)

        # xys1 = self._mapStatus.geometry1.poly.xy

        # xys2 = self._mapStatus.geometry2.poly.xy
        # index = 0
        # for xy in xys1:
        #     xys2 = np.insert(xys2, mergePointIndex + index, xy, axis=0)
        #     index += 1

        # self._mapStatus.geometry2.addPoints(xys2)
