from enums.status import Status
from models.geometry import Geometry

class MapStatus:
    def __init__(self):
        self.status = Status.IDLE
        self.geometry1: Geometry = None
        self.geometry2: Geometry = None
        self.selectedPointIndex1 = None
        self.selectedPointIndex2 = None