from matplotlib.axes import Axes
from geometry_msgs.msg import Polygon

from models.area import Area

class MowingArea(Area):
    def __init__(self, ax: Axes, area: Polygon, obstacles: list[Polygon]):

        super().__init__(ax, area, obstacles)
        self.type = 'Mowing Area'
        self.poly.set_facecolor('limegreen')
        self.line.set_markerfacecolor('forestgreen')
        self.selectPoint(0)
        