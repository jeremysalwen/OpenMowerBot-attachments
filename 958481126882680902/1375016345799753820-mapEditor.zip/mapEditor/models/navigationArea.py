from matplotlib.axes import Axes
from geometry_msgs.msg import Polygon

from models.area import Area

class NavigationArea(Area):
    def __init__(self, ax: Axes, area: Polygon, obstacles: list[Polygon]):

        super().__init__(ax, area, obstacles)
        self.type = 'Navigation Area'
        self.poly.set_facecolor('white')
        self.line.set_markerfacecolor('black')
