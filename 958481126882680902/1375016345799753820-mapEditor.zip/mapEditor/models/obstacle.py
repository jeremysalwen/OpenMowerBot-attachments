from matplotlib.axes import Axes
from geometry_msgs.msg import Point32

from models.geometry import Geometry

class Obstacle(Geometry):
    def __init__(self, ax: Axes, points: list[Point32], parent):

        super().__init__(ax, points)
        self.type = 'Obstacle'
        self.poly.set_facecolor('red')
        self.line.set_markerfacecolor('firebrick')
        self.parent = parent

    def delete(self):
        super().delete()
        self.parent.obstacles.remove(self)

