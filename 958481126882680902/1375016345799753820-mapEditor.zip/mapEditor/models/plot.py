import matplotlib.pyplot as plt
from enums.axesText import AxesText;
from matplotlib.patches import Patch

class Plot:
    def __init__(self):
        fig, axes = plt.subplots(1, 1)
        self.epsilon = 10 #5  # max pixel distance to count as a vertex hit
        self.canvas = fig.canvas
        self.axes = axes
        self.axes.set_title(AxesText.PLOT_TITLE.value, x=0, size=8, fontfamily='monospace', ha='left')
        self.axes.set_xlabel(AxesText.DEFAULT.value, x=0, size=8, fontfamily='monospace', ha='left')
        self.axes.set_xticks([], None)
        self.axes.set_yticks([], None)
        self.axes.set_aspect('equal')
        self.axes.format_coord = lambda x, y : f''
        self.timer = self.canvas.new_timer(interval=2000)
        self.canvas.zorder = 0
        self.canvas.manager.set_window_title('OpenMower Map editor')
        self.canvas.manager.toolmanager.remove_tool('back')
        self.canvas.manager.toolmanager.remove_tool('forward')
        self.canvas.manager.toolmanager.remove_tool('subplots')
        self.canvas.manager.toolmanager.remove_tool('save')
        self.canvas.manager.toolmanager.remove_tool('help')
        self.canvas.background = None

    def getPatchUnderTheMouse(self, event):
        patches = list[Patch]()
        for patch in self.axes.patches:
            if patch.get_visible() == False:
                continue
            if patch.contains_point([event.x, event.y]):
                patches.append(patch)
        
        if len(patches) == 0:
            return None

        zorderedPatches = sorted(patches, key=lambda patch: patch.zorder, reverse=True)

        return zorderedPatches[0]
    
    def setAxesText(self, axesText: AxesText):
        self.axes.set_xlabel(axesText.value, ha='left')

    def showStatusText(self, text, autohide=True):
        self.axes.set_title(text, x=0, size=8, fontfamily='monospace', ha='left')
        self.canvas.draw()
        if autohide == False:
            return
        self.timer.add_callback(self.hideStatusText)
        self.timer.start()

    def hideStatusText(self):
        self.axes.set_title(AxesText.PLOT_TITLE.value, x=0, size=8, fontfamily='monospace', ha='left')
        self.canvas.draw()
        self.timer.stop()

