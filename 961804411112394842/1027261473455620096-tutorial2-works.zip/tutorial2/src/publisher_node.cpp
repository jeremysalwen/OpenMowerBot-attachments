// #include "ros/ros.h"
// #include "sensor_msgs/Joy.h"
// #include "gpiod.h"
// #include "std_msgs/String.h"
// #include "tutorial2/person_data.h"

// int main(int argc, char **argv){
//   ros::init(argc, argv, "Publisher");
//   ros::NodeHandle nh;

//   ros::Publisher topic_pub = nh.advertise<tutorial2::person_data>("tutorial", 1000);
//   ros::Rate loop_rate(1);

//   while(ros::ok()){
//     tutorial2::person_data person_data;
//     person_data.name = "Miguel";
//     person_data.age = 25;
//     person_data.color = "Yellow";

//     topic_pub.publish(msg);
//     ros::spinOnce();
//     loop_rate.sleep();
//   }

//   return 0;
// }