// #include "ros/ros.h"
// #include "sensor_msgs/Joy.h"
// #include "gpiod.h"
// #include "std_msgs/String.h"
// #include "tutorial2/person_data.h"

// void writeMsgToLog(const tutorial2::person_data &person_data){
//     ROS_INFO("Name: %s", person_data.name.c_str());
//     ROS_INFO("Age: %i", person_data.age.c_str());
//     ROS_INFO("Color: %s", person_data.color.c_str());
// }

// int main(int argc, char **argv){
//     ros::init(argc, argv, "Subscriber");
//     ros::NodeHandle nh;

//     ros::Subscriber topic_pub = nh.subscribe("tutorial", 1000, writeMsgToLog);

//     ros::spin();

//   return 0;
// }