# Ecovacs Top MCU - Custom Firmware

Custom firmware for the Ecovacs Top MCU board based on GD32F103C8T6.

## ⚠️ First Time Setup

**Delete these files after cloning** (they conflict with Arduino framework):
```
src/main.c      <- DELETE (we use main.cpp now)
src/systick.c   <- DELETE (Arduino has its own timing)
include/systick.h <- DELETE (not needed)
```

## Hardware

- **MCU**: GD32F103C8T6 (LQFP48)
- **Flash**: 64KB internal + 1MB external (GD25Q80)
- **RAM**: 20KB
- **Clock**: 72MHz (8MHz HSE with PLL)
- **Display**: ST7565/UC1701 128x64 LCD (via U8g2)
- **Buttons**: 8 + Reset (active-low)
- **UART**: 2x (Serial1 @ 9600, Serial2 @ 115200)

## Pin Mapping

See `include/pin_definitions.h` for complete pin assignments.

### Key Pins

| Pin  | Function      | Arduino     | Notes                          |
|------|---------------|-------------|--------------------------------|
| PA0  | LCD Backlight | `PA0`       | Output, HIGH=ON                |
| PA2  | USART2 TX     | `Serial2`   | Main comm to Linux SBC         |
| PA3  | USART2 RX     | `Serial2`   | Main comm from Linux SBC       |
| PA4  | LCD CS        | `PA4`       | Chip select (active low)       |
| PA5  | LCD SCK       | `PA5`       | SPI clock (bit-banged)         |
| PA7  | LCD MOSI      | `PA7`       | SPI data out (bit-banged)      |
| PB0  | LCD RST       | `PB0`       | Reset (active low)             |
| PB1  | LCD DC        | `PB1`       | Data/Command select            |
| PB3-9| Buttons       | `PB3-PB9`   | Active-low with pull-up        |
| PA15 | Button 7      | `PA15`      | Active-low with pull-up        |
| PA1  | Reset Button  | `PA1`       | Long-press detection           |

## Building

### Prerequisites

1. Install [PlatformIO](https://platformio.org/)
2. Install VS Code with PlatformIO extension (recommended)

### Build Commands

```bash
# Build firmware (uses CommunityGD32Cores)
pio run

# If GD32 platform has issues, try STM32 compatible build:
pio run -e bluepill_compat

# Clean build
pio run -t clean
```

### Build Environments

| Environment        | Platform              | Notes                      |
|--------------------|-----------------------|----------------------------|
| `gd32f103c8`       | CommunityGD32Cores    | Native GD32 (recommended)  |
| `bluepill_compat`  | STM32Duino            | STM32F103 compatible mode  |
| `stm32_hal`        | STM32Cube HAL         | Low-level HAL              |

## Display Library: U8g2

We use [U8g2](https://github.com/olikraus/u8g2) for graphics support. It provides:

- ✅ Full graphics primitives (lines, rectangles, circles)
- ✅ Multiple fonts (from tiny 5x7 to large display fonts)
- ✅ Text rendering with positioning
- ✅ XBM bitmap support
- ✅ Double buffering (full frame buffer mode)

### U8g2 Quick Reference

```cpp
// Drawing
u8g2.drawPixel(x, y);
u8g2.drawLine(x1, y1, x2, y2);
u8g2.drawFrame(x, y, w, h);      // Rectangle outline
u8g2.drawBox(x, y, w, h);        // Filled rectangle
u8g2.drawCircle(x, y, r);
u8g2.drawDisc(x, y, r);          // Filled circle

// Text
u8g2.setFont(u8g2_font_6x10_tf);
u8g2.drawStr(x, y, "Hello");
u8g2.setCursor(x, y);
u8g2.print("Value: ");
u8g2.print(123);

// Bitmaps (XBM format)
u8g2.drawXBM(x, y, width, height, bitmap_data);

// Display control
u8g2.clearBuffer();
u8g2.sendBuffer();
u8g2.setContrast(value);         // 0-255
```

### Available Fonts (selection)

```cpp
u8g2_font_5x7_tf          // Tiny
u8g2_font_6x10_tf         // Small
u8g2_font_8x13_tf         // Medium
u8g2_font_10x20_tf        // Large
u8g2_font_ncenB14_tr      // Nice serif
u8g2_font_helvB12_tr      // Helvetica bold
```

Full font list: https://github.com/olikraus/u8g2/wiki/fntlistall

## Flashing

### Option 1: GD32 System Bootloader (UART)

The GD32F103 has a built-in bootloader in ROM.

1. **Hardware Setup**:
   - Connect USB-UART adapter to PA2 (TX) and PA3 (RX)
   - Cross-connect: Adapter TX → MCU RX (PA3), Adapter RX → MCU TX (PA2)
   - Connect BOOT0 to 3.3V
   - Keep BOOT1 at GND

2. **Enter Bootloader Mode**:
   - Set BOOT0 = HIGH
   - Reset the MCU

3. **Flash**:
   ```bash
   # Install stm32flash
   # Windows: download from https://sourceforge.net/projects/stm32flash/
   # Linux: sudo apt install stm32flash
   
   # Flash firmware
   stm32flash -w .pio/build/gd32f103c8/firmware.bin -v -g 0x0 COM3
   ```

4. **Run Firmware**:
   - Set BOOT0 = LOW
   - Reset the MCU

### Option 2: SWD Debug Probe

Connect ST-Link or J-Link to:
- PA13 (SWDIO)
- PA14 (SWCLK)
- GND
- 3.3V (optional)

```bash
pio run -t upload -e bluepill_compat --upload-port stlink
```

## Debug Output

```bash
# Monitor Serial2 output
pio device monitor -p COM4 -b 115200
```

## Project Structure

```
Firmware_Top_MCU/
├── platformio.ini          # Build configuration
├── README.md               # This file
├── include/
│   └── pin_definitions.h   # GPIO pin mappings
├── src/
│   └── main.cpp            # Main application (Arduino)
└── lib/                    # Custom libraries
```

## Features

### Current
- ✅ System initialization at 72MHz
- ✅ ST7565 LCD with U8g2 graphics
- ✅ Backlight control
- ✅ Button scanning with debounce
- ✅ Serial debug output (Serial2 @ 115200)
- ✅ Basic SA protocol key events

### Planned
- [ ] Full SA Protocol parser/handler
- [ ] Menu system / UI pages
- [ ] SPI2 flash driver (GD25Q80)
- [ ] USART1 GPS/NMEA passthrough
- [ ] Key event types (double-click, long-press)
- [ ] Custom bootloader for OTA

## SA Protocol Integration

The firmware sends key events in SA protocol format:

```
@Ka<keycode>*
```

Example: `@KaA0*` = Button 4 (PB7) pressed

See `../Docs_Top_MCU/Pin_Definitions.md` for full protocol documentation.

## License

MIT License - Use at your own risk.
