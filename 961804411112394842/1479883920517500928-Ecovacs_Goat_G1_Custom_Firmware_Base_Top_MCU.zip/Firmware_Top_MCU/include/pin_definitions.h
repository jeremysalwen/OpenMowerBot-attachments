/**
 * @file pin_definitions.h
 * @brief GPIO Pin definitions for Ecovacs Top MCU (GD32F103C8T6)
 * 
 * Derived from reverse engineering of original firmware.
 * Source: top_mcu_original.bin @ 0x08003000
 * 
 * Compatible with STM32Duino framework
 * GD32F103 is 99% compatible with STM32F103
 * 
 * STM32Duino Pin Naming: PA0, PA1, PB0, PB1, etc. (no underscore)
 * 
 * @note Active-low buttons with internal pull-ups
 * @note Display uses bit-banged SPI (not hardware SPI1)
 * @note SPI2 is hardware SPI for external flash
 */

#ifndef PIN_DEFINITIONS_H
#define PIN_DEFINITIONS_H

#include <Arduino.h>

// =============================================================================
// Display Pins (ST7565/UC1701 - Bit-banged SPI)
// =============================================================================

#define PIN_LCD_BACKLIGHT   PA0     // Backlight enable (HIGH=ON)
#define PIN_LCD_CS          PA4     // Chip Select (active low)
#define PIN_LCD_SCK         PA5     // Serial Clock
#define PIN_LCD_MOSI        PA7     // Master Out Slave In
#define PIN_LCD_RST         PB0     // Reset (active low)
#define PIN_LCD_DC          PB1     // Data/Command (A0): 0=cmd, 1=data

// Display specs
#define LCD_WIDTH           128
#define LCD_HEIGHT          64
#define LCD_PAGES           8       // 64 pixels / 8 bits per page

// =============================================================================
// Button Pins (Active-low, Internal Pull-up)
// =============================================================================

#define PIN_BTN_0           PB3     // Keycode 0xA3
#define PIN_BTN_1           PB4     // Keycode 0xA5
#define PIN_BTN_2           PB5     // Keycode 0xA4
#define PIN_BTN_3           PB6     // Keycode 0xA2
#define PIN_BTN_4           PB7     // Keycode 0xA0
#define PIN_BTN_5           PB8     // Keycode 0xA1
#define PIN_BTN_6           PB9     // Keycode 0xA6
#define PIN_BTN_7           PA15    // Keycode 0xA7
#define PIN_BTN_RESET       PA1     // Reset button (long-press detection)

// Keycodes (as sent via SA protocol)
#define KEYCODE_BTN_0       0xA3    // PB3
#define KEYCODE_BTN_1       0xA5    // PB4
#define KEYCODE_BTN_2       0xA4    // PB5
#define KEYCODE_BTN_3       0xA2    // PB6
#define KEYCODE_BTN_4       0xA0    // PB7
#define KEYCODE_BTN_5       0xA1    // PB8
#define KEYCODE_BTN_6       0xA6    // PB9
#define KEYCODE_BTN_7       0xA7    // PA15

// =============================================================================
// UART Pins
// =============================================================================

// USART1 - Secondary (GPS/NMEA input @ 9600 baud) -> Serial1
#define PIN_USART1_TX       PA9
#define PIN_USART1_RX       PA10
#define USART1_BAUD         115200

// USART2 - Main communication to Linux SBC @ 115200 baud -> Serial2
#define PIN_USART2_TX       PA3
#define PIN_USART2_RX       PA2
#define USART2_BAUD         115200

// =============================================================================
// SPI2 Pins (Hardware SPI - External Flash GD25Q80)
// =============================================================================

#define PIN_SPI2_NSS        PB12    // Chip Select (software controlled)
#define PIN_SPI2_SCK        PB13    // Serial Clock
#define PIN_SPI2_MISO       PB14    // Master In Slave Out
#define PIN_SPI2_MOSI       PB15    // Master Out Slave In

// =============================================================================
// USB Pins (unused in original firmware, available for custom use)
// =============================================================================

#define PIN_USB_DM          PA11    // USB D-
#define PIN_USB_DP          PA12    // USB D+

// =============================================================================
// Debug Pins (SWD) - Keep available!
// =============================================================================

#define PIN_SWDIO           PA13
#define PIN_SWCLK           PA14

// =============================================================================
// Memory Map
// =============================================================================

#define FLASH_BASE_ADDR         0x08000000
#define BOOTLOADER_SIZE         0x3000          // 12KB
#define APP_BASE_ADDR           0x08003000      // Application start
#define FLASH_SIZE              0x10000         // 64KB total
#define SRAM_BASE_ADDR          0x20000000
#define SRAM_SIZE               0x5000          // 20KB

// External SPI Flash (GD25Q80)
#define EXT_FLASH_SIZE          0x100000        // 1MB
#define EXT_FLASH_SECTOR_SIZE   0x1000          // 4KB
#define EXT_FLASH_PAGE_SIZE     256

#endif // PIN_DEFINITIONS_H
