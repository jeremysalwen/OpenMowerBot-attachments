/**
 * @file main.cpp
 * @brief Ecovacs Top MCU - Custom Firmware (Serial Debug Version)
 * 
 * Display: WORKING! ✓
 * Serial: Debugging...
 */

#include <Arduino.h>
#include <U8g2lib.h>

// =============================================================================
// Serial2 Setup (USART2 on PA2/PA3)
// =============================================================================

#if !defined(HAVE_HWSERIAL2) && !defined(Serial2)
HardwareSerial Serial2(PA3, PA2);  // RX, TX
#endif

// =============================================================================
// Pin Definitions
// =============================================================================

#define PIN_LCD_BACKLIGHT   PA0
#define PIN_LCD_CS          PA4
#define PIN_LCD_SCK         PA5
#define PIN_LCD_MOSI        PA7
#define PIN_LCD_RST         PB0
#define PIN_LCD_DC          PB1

// =============================================================================
// Manual SPI Display Functions (WORKING!)
// =============================================================================

void lcd_spi_write(uint8_t data) {
    for (int i = 7; i >= 0; i--) {
        digitalWrite(PIN_LCD_SCK, LOW);
        digitalWrite(PIN_LCD_MOSI, (data >> i) & 1);
        digitalWrite(PIN_LCD_SCK, HIGH);
    }
}

void lcd_cmd(uint8_t cmd) {
    digitalWrite(PIN_LCD_DC, LOW);
    digitalWrite(PIN_LCD_CS, LOW);
    lcd_spi_write(cmd);
    digitalWrite(PIN_LCD_CS, HIGH);
}

void lcd_data(uint8_t data) {
    digitalWrite(PIN_LCD_DC, HIGH);
    digitalWrite(PIN_LCD_CS, LOW);
    lcd_spi_write(data);
    digitalWrite(PIN_LCD_CS, HIGH);
}

void lcd_init_oem() {
    pinMode(PIN_LCD_BACKLIGHT, OUTPUT);
    pinMode(PIN_LCD_CS, OUTPUT);
    pinMode(PIN_LCD_SCK, OUTPUT);
    pinMode(PIN_LCD_MOSI, OUTPUT);
    pinMode(PIN_LCD_RST, OUTPUT);
    pinMode(PIN_LCD_DC, OUTPUT);
    
    digitalWrite(PIN_LCD_CS, HIGH);
    digitalWrite(PIN_LCD_SCK, LOW);
    
    digitalWrite(PIN_LCD_RST, LOW);
    delay(50);
    digitalWrite(PIN_LCD_RST, HIGH);
    delay(10);
    
    lcd_cmd(0xE2); delay(10);
    lcd_cmd(0xA2);
    lcd_cmd(0xA0);
    lcd_cmd(0xC8);
    lcd_cmd(0x24); delay(20);
    lcd_cmd(0x81);
    lcd_cmd(0x3F); delay(10);
    lcd_cmd(0x2C); delay(10);
    lcd_cmd(0x2E); delay(10);
    lcd_cmd(0x2F); delay(10);
    lcd_cmd(0xAF); delay(10);
}

void lcd_clear() {
    for (uint8_t page = 0; page < 8; page++) {
        lcd_cmd(0xB0 | page);
        lcd_cmd(0x10);
        lcd_cmd(0x00);
        for (uint8_t col = 0; col < 128; col++) {
            lcd_data(0x00);
        }
    }
}

// Simple 5x7 font - just digits and some chars for status display
const uint8_t font5x7[][5] = {
    {0x3E, 0x51, 0x49, 0x45, 0x3E}, // 0
    {0x00, 0x42, 0x7F, 0x40, 0x00}, // 1
    {0x42, 0x61, 0x51, 0x49, 0x46}, // 2
    {0x21, 0x41, 0x45, 0x4B, 0x31}, // 3
    {0x18, 0x14, 0x12, 0x7F, 0x10}, // 4
    {0x27, 0x45, 0x45, 0x45, 0x39}, // 5
    {0x3C, 0x4A, 0x49, 0x49, 0x30}, // 6
    {0x01, 0x71, 0x09, 0x05, 0x03}, // 7
    {0x36, 0x49, 0x49, 0x49, 0x36}, // 8
    {0x06, 0x49, 0x49, 0x29, 0x1E}, // 9
};

void lcd_draw_char(uint8_t page, uint8_t col, char c) {
    lcd_cmd(0xB0 | page);
    lcd_cmd(0x10 | ((col >> 4) & 0x0F));
    lcd_cmd(0x00 | (col & 0x0F));
    
    if (c >= '0' && c <= '9') {
        for (int i = 0; i < 5; i++) {
            lcd_data(font5x7[c - '0'][i]);
        }
        lcd_data(0x00); // spacing
    } else {
        for (int i = 0; i < 6; i++) {
            lcd_data(0x00);
        }
    }
}

void lcd_draw_number(uint8_t page, uint8_t col, uint32_t num) {
    char buf[12];
    sprintf(buf, "%lu", num);
    for (int i = 0; buf[i]; i++) {
        lcd_draw_char(page, col + i * 6, buf[i]);
    }
}

// =============================================================================
// Multi-Baudrate Serial Test
// =============================================================================

// Common baud rates to try
const uint32_t baudRates[] = {9600, 19200, 38400, 57600, 115200, 230400};
const int numBaudRates = sizeof(baudRates) / sizeof(baudRates[0]);
int currentBaudIndex = 3;  // Start with 115200

void serial_send_test_pattern() {
    // Send recognizable pattern at current baud rate
    Serial2.println();
    Serial2.println(F("############################"));
    Serial2.print(F("# BAUD: "));
    Serial2.print(baudRates[currentBaudIndex]);
    Serial2.println(F(" #"));
    Serial2.println(F("# Ecovacs Top MCU Custom  #"));
    Serial2.println(F("# Press BTN to change     #"));
    Serial2.println(F("############################"));
    Serial2.println();
    Serial2.println(F("ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
    Serial2.println(F("0123456789"));
    Serial2.println();
}

void serial_change_baud() {
    currentBaudIndex = (currentBaudIndex + 1) % numBaudRates;
    Serial2.end();
    delay(10);
    Serial2.begin(baudRates[currentBaudIndex]);
    delay(50);
    serial_send_test_pattern();
}

// =============================================================================
// Setup
// =============================================================================

void setup() {
    // Backlight ON
    pinMode(PIN_LCD_BACKLIGHT, OUTPUT);
    digitalWrite(PIN_LCD_BACKLIGHT, HIGH);
    
    delay(100);
    
    // Init display (WORKING!)
    lcd_init_oem();
    lcd_clear();
    
    // Show startup on display
    // Draw "SERIAL" on page 0
    lcd_cmd(0xB0);
    lcd_cmd(0x10);
    lcd_cmd(0x00);
    for (int i = 0; i < 128; i++) lcd_data(0xFF);  // Line
    
    // Show current baud on display
    lcd_draw_number(2, 10, baudRates[currentBaudIndex]);
    
    // Button setup
    pinMode(PB3, INPUT_PULLUP);
    pinMode(PB7, INPUT_PULLUP);
    pinMode(PA1, INPUT_PULLUP);
    
    // Start Serial2
    Serial2.begin(baudRates[currentBaudIndex]);
    delay(100);
    
    serial_send_test_pattern();
}

// =============================================================================
// Main Loop
// =============================================================================

uint32_t lastBlink = 0;
uint32_t lastSerialSend = 0;
bool blinkState = false;
uint32_t counter = 0;

void loop() {
    uint32_t now = millis();
    
    // Heartbeat blink (250ms = faster)
    if (now - lastBlink > 250) {
        lastBlink = now;
        blinkState = !blinkState;
        digitalWrite(PIN_LCD_BACKLIGHT, blinkState ? HIGH : LOW);
    }
    
    // Send serial test every 2 seconds
    if (now - lastSerialSend > 2000) {
        lastSerialSend = now;
        counter++;
        
        Serial2.print(F("Tick #"));
        Serial2.print(counter);
        Serial2.print(F(" @ "));
        Serial2.print(baudRates[currentBaudIndex]);
        Serial2.print(F(" baud | Uptime: "));
        Serial2.print(now / 1000);
        Serial2.println(F("s"));
        
        // Update display with counter
        lcd_draw_number(4, 10, counter);
        lcd_draw_number(6, 10, now / 1000);
    }
    
    // Button PB3: Change baud rate
    static bool lastBtn3 = HIGH;
    bool btn3 = digitalRead(PB3);
    if (btn3 == LOW && lastBtn3 == HIGH) {
        serial_change_baud();
        lcd_clear();
        lcd_draw_number(2, 10, baudRates[currentBaudIndex]);
        delay(200);
    }
    lastBtn3 = btn3;
    
    // Button PB7: Send test pattern
    static bool lastBtn7 = HIGH;
    bool btn7 = digitalRead(PB7);
    if (btn7 == LOW && lastBtn7 == HIGH) {
        serial_send_test_pattern();
        delay(200);
    }
    lastBtn7 = btn7;
    
    // Button PA1 (Reset): Also change baud
    static bool lastBtnReset = HIGH;
    bool btnReset = digitalRead(PA1);
    if (btnReset == LOW && lastBtnReset == HIGH) {
        serial_change_baud();
        lcd_clear();
        lcd_draw_number(2, 10, baudRates[currentBaudIndex]);
        delay(200);
    }
    lastBtnReset = btnReset;
    
    delay(10);
}
