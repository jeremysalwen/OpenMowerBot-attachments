#include "Arduino.h"
#include "Wire.h"

#define CARRIER_EEPROM_DEVICE_ADDRESS 0b1010000
#define CARRIER_BOARD_INFO_ADDRESS 0x00

#define PIN_WP 6

#pragma pack(push, 1)
struct carrier_board_info
{
    uint8_t board_info_version;
    char board_id[32];
    uint8_t version_major;
    uint8_t version_minor;
    uint16_t version_patch;
    uint16_t checksum;
} __attribute__((packed));
#pragma pack(pop)

bool done = false;
int count = 0;
int success = 0;
int fail = 0;

void setup()
{
    Wire.begin();
    while (!Serial)
        ;
    Serial.begin(115200);
    pinMode(PIN_WP, OUTPUT);
}

bool EEPROM_write(uint8_t eeprom_address, uint8_t memory_address, uint8_t *data, size_t length)
{
    Wire.setClock(10000);
    // Write
    for (size_t i = 0; i < length; i++)
    {
        Wire.beginTransmission(eeprom_address);
        Wire.write(memory_address + i);
        Wire.write(data[i]);
        if (Wire.endTransmission() != 0)
        {
            return false;
        }
        delay(5);
    }
    return true;
}

bool EEPROM_verify(uint8_t eeprom_address, uint8_t memory_address, const uint8_t *data, size_t length)
{
    Wire.setClock(10000);
    Wire.beginTransmission(eeprom_address);
    Wire.write(memory_address);
    Wire.endTransmission();

    Wire.requestFrom(eeprom_address, length);
    for (size_t i = 0; i < length; i++)
    {
        if (data[i] != Wire.read())
        {
            return false;
        }
    }
    return true;
}

bool EEPROM_read(uint8_t eeprom_address, uint8_t memory_address, uint8_t *data, size_t length)
{
    Wire.setClock(10000);
    Wire.beginTransmission(eeprom_address);
    Wire.write(memory_address);
    if (Wire.endTransmission() != 0)
    {
        return false;
    }

    Wire.requestFrom(eeprom_address, length);
    for (size_t i = 0; i < length; i++)
    {
        data[i] = Wire.read();
    }
    return true;
}

uint16_t checksum(void *data, size_t length)
{
    uint16_t sum = 0;
    for (size_t i = 0; i < length; i++)
    {
        if (i % 2 == 0)
        {
            sum ^= ((uint8_t *)data)[i];
        }
        else
        {
            sum ^= (((uint8_t *)data)[i]) << 8;
        }
    }
    return sum;
}

bool writeCarrierEEPROM()
{
    Serial.println("Writing carrier EEPROM");

    struct carrier_board_info info = {0};
    //strncpy(info.board_id, "hw-openmower-universal", sizeof(info.board_id));
    strncpy(info.board_id, "hw-openmower-yardforce", sizeof(info.board_id));
    info.version_major = 1;
    info.version_minor = 1;
    info.version_patch = 0;
    info.board_info_version = 1;
    info.checksum = checksum(&info, sizeof(info) - 2);

    Serial.print("board: ");
    Serial.println(info.board_id);
    Serial.print("version: ");
    Serial.print(info.version_major);
    Serial.print(".");
    Serial.print(info.version_minor);
    Serial.print(".");
    Serial.println(info.version_patch);


    // Allow Write
    digitalWrite(PIN_WP, LOW);
    if (!EEPROM_write(CARRIER_EEPROM_DEVICE_ADDRESS, CARRIER_BOARD_INFO_ADDRESS, (uint8_t *)&info, sizeof(info)))
    {
        digitalWrite(PIN_WP, HIGH);
        Serial.println("EEPROM write failed");
                Serial.println("####################");
        Serial.println("###### ERROR #####");
        Serial.println("####################");
        return false;
    }
    Serial.println("EEPROM write success");
    // Deny Write
    digitalWrite(PIN_WP, HIGH);
    if (!EEPROM_verify(CARRIER_EEPROM_DEVICE_ADDRESS, CARRIER_BOARD_INFO_ADDRESS, (uint8_t *)&info, sizeof(info)))
    {
        digitalWrite(PIN_WP, HIGH);
        Serial.println("EEPROM verify failed");
                Serial.println("####################");
        Serial.println("###### ERROR #####");
        Serial.println("####################");
        return false;
    }
    Serial.println("EEPROM verify success");
        Serial.println("####################");
    Serial.println("###### SUCCESS #####");
    Serial.println("####################");
    delay(2000);
    return true;
}


bool doIt()
{
    count++;
    if (!writeCarrierEEPROM())
    {
        fail++;
        return false;
    }
    success++;
    return true;
}

void loop()
{
    Serial.println("ready. S for start.");
    delay(1000);

    if (Serial.available())
    {
        char c = Serial.read();
        switch (c)
        {
        case 'S':
            doIt();
            Serial.print("count: ");
            Serial.print(count);
            Serial.print(", success: ");
            Serial.print(success);
            Serial.print(", fail: ");
            Serial.println(fail);
            break;

        default:
            break;
        }
    }
}
